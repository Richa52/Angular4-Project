<?php include('common.php'); $page='about'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - About Us</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/main.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="about-us">
        <div class="col-sm-6 left-spacer">
            <div class="line-header">About Us</div>
            <div class="about-description">
                High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city’s first luxury and premium retail and entertainment destination. 
            </div>
        </div>

        <div class="col-sm-6 sm-pull-right">
          <div class="home-slider">
            <div class="slider-wrapper">
                <div class="main-slider">
                  <div id="slideshowHolder" active-slider="1" style="position: relative;">
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img1' />
                    </div>
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img2' />
                    </div>
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img3' />
                    </div>
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img1' />
                    </div>
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img2' />
                    </div>
                    <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img3' />
                    </div>
                  </div>
                  <div class="timer"></div>
                </div>
                
            </div> 
          </div>
        </div>
        <div class="col-sm-6 left-spacer">
            <div class="readmore-line">Read more about Palladium &nbsp;&nbsp;&nbsp;<div class="grow-line"></div></div>
            <div class="about-description read-more-scroll">
                This south Mumbai mall has in a short span of time become an iconic landmark not only for the elite of the city but also for many around the country. What makes Palladium so irresistible are the four levels of exceptional shopping in an atmosphere of sophistication and refinement under one elegant roof. <br><br>

                Its unique design expression makes the mall a striking structure in the architecture of the city that never sleeps. <br><br>

                Palladium has become a landmark already. The retail and lifestyle mix of the mall comes alive with the luxury labels, high fashion brands, cafes, fine dining restaurants, a stand-up comedy venue, spas and salons it houses. <br><br>

                This truly one of its kind luxury retail space in India also provides for special services such as a concierge desk, Wi-Fi and valet parking for all visitors.</div>
        </div>
        <div class="clearfix"></div>
    </section>
    
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   <script type="text/javascript">
    var scroll_div=$('.read-more-scroll');
    scroll_div.scroll(function() {
        var height = scroll_div[0].scrollHeight - scroll_div.innerHeight();
        var pos = scroll_div.scrollTop();//+20;
        var width=(pos/height)*100;
        // console.log(pos, height, width);
        // $('section.about-us .readmore-line .grow-line').animate({'width': width+'%'});
        $('section.about-us .readmore-line .grow-line').css('width', width+'%');
    });

       
   </script>
        
    </body>
</html>
