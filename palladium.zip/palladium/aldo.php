<?php include('common.php'); $page='brands'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Brands</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/brands.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="nonseo relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="brands-header brands-individual left-spacer right-spacer">
        <div class="line-header">Brands</div>       
    </section>
    <section class="brands-content left-spacer right-spacer">
        <div class="col-sm-6 brands-image">
            <!-- <img src="<?php echo $base_url ?>img/brands/individual/aldo.png" class="">
            <img src="<?php echo $base_url ?>img/banner-01.png" class="">
            <img src="<?php echo $base_url ?>img/banner-02.png" class=""> -->
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/brands/individual/aldo.png" class=""></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/banner-01.png" class=""></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/banner-02.png" class=""></div>
                </div>            
                <div class="swiper-pagination"></div>
            </div>
        </div>
        <div class="col-sm-6 back-to-brands"><a href="<?php echo $base_url ?>brands">back</a></div>         
        <div class="col-sm-6 brands-details">
            <div class="brand-name">Aldo</div>
            <div class="brand-location"><div class="sprite bg-location"></div>Palladium level 01</div>
            <div class="brands-time"><div class="sprite bg-time"></div>11 am To 10 pm</div>
            <div class="brands-contact"><div class="sprite bg-call"></div>+91-93237 892 44</div>
        </div> 
        <div class="clearfix"></div>
        <div class="brands-description">ALDO India provides an unparalleled selection of the latest footwear and accessories for both men and women, with on-trend styles at a fair price. ALDO has also introduced their Accessories collection. Customers can enjoy the same quality and affordability in accessories as they have come to expect in footwear. Every season ALDO Accessories reveals a new selection of merchandise that is fresh, on-trend and reflective of what is hot on the global fashion scene. This unique retail concept has quickly become a top destination for all the must-haves in accessories and handbags. <br><br>

        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at mi ligula. Quisque mollis posuere consectetur. Pellentesque in ante pharetra, vulputate erat a, interdum ante. Ut varius vehicula varius. Nulla dignissim dignissim dignissim. Nunc sit amet nisi lobortis, iaculis nulla et, pretium nulla. Duis bibendum risus justo, ac aliquet justo suscipit ut. Proin auctor dui pretium justo congue, nec posuere purus interdum. Curabitur quis risus ut nunc lobortis fermentum a vel lectus. Sed blandit mollis augue eu egestas. <br><br>

        Nulla finibus ex non quam convallis tempus ut sed nulla. Vestibulum ut enim orci. Morbi vitae neque mi. Nullam velit orci, interdum a lectus malesuada, sagittis viverra sapien. Donec bibendum.</div>        
    </section>  
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
