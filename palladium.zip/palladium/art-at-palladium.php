<?php include('common.php'); $page='events'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Events</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/events.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="event-header event-individual left-spacer right-spacer">
        <div class="line-header">Events</div>       
    </section>
    <section class="event-content">
        <div class="col-sm-6 event-image-slider">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                </div>
                <div class="swiper-pagination"></div>
            </div>           
        </div>
        <div class="col-sm-6 back-to-event description-spacer"><a href="<?php echo $base_url ?>events">back</a></div>         
        <div class="col-sm-6 event-details description-spacer">
            <div class="event-name">Art at Palladium</div>
            <div class="event-location"><div class="sprite bg-location"></div>Palladium atrium</div>
            <div class="event-time"><div class="sprite bg-time"></div>15<sup>th</sup> March, 2017</div>
        </div> 
        <div class="col-sm-6 event-description description-spacer">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ligula dui, lacinia vitae arcu nec, venenatis tristique elit. Aenean tincidunt molestie nisi at facilisis. Etiam malesuada luctus risus ut fringilla. Ut ut luctus arcu, vitae egestas nibh. <br><br>
            Ut sollicitudin quam sit amet enim egestas aliquet. Nunc gravida id nibh non tincidunt. Nulla id vehicula augue. Ut luctus magna non turpis hendrerit, sed tincidunt odio volutpat.
        </div>
        <div class="col-sm-6 booking-form description-spacer">
            <div class="">
                <div class="booking-head">booking details</div>

                <form id="booking_details" class="form-horizontal" method="post" novalidate>
                    <div class="form-group">
                        <div class="col-sm-10 group">
                            <input type="text" id="name" name="name" class="form_fields form-control" placeholder="Name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-10 group">
                            <input type="tel" name="phone" class="form_fields form-control" placeholder="Phone" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-10 group">
                            <input type="email" name="email" class="form_fields form-control" placeholder="Email" required> 
                        </div>
                    </div>
                    <div class="form-group submit_group">
                        <div class="col-sm-12">
                            <input class="booking_submit" type="submit" name="" value="stay updated">
                        </div>
                    </div>
                </form>
            </div>
        </div>  
    </section> 
    <section class="related-events container">
        <div class="related-events-head">Related Events</div>
            <div class="related-events-wrapped">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/events/events-04.png" class="img-responsive"></div>
                            <div class="event-name">lakme fashion show</div>
                            <div class="event-place">Palladium Atrium</div>
                            <div class="event-time">15th October, 2017</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/events/events-03.png" class="img-responsive"></div>
                            <div class="event-name">summer decor</div>
                            <div class="event-place">Palladium Atrium</div>
                            <div class="event-time">25th May, 2017</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/events/events-02.png" class="img-responsive"></div>
                            <div class="event-name">lorem ipsum dot amet</div>
                            <div class="event-place">Palladium Entrance</div>
                            <div class="event-time">1st June, 2017</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/events/events-05.png" class="img-responsive"></div>
                            <div class="event-name">musical concert</div>
                            <div class="event-place">Palladium Level 01</div>
                            <div class="event-time">20th October, 2017</div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>    
                </div>             
                <div class="next-slide-arrows"></div>
                <div class="prev-slide-arrows"></div>
                
            </div>
    </section>   
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
