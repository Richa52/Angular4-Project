<?php include('common.php');   $page='awards';  ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Awards</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <?php include('header.php'); ?>   


    <section class="menu-gap"></section>

    <section class="awards left-spacer">
        <div class="line-header">Awards</div>
        <div class="clearfix"></div>
        <div class="col-sm-7 awards-description">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ligula dui, lacinia vitae arcu nec, venenatis tristique elit. Aenean tincidunt molestie nisi at facilisis. Etiam malesuada luctus risus ut fringilla. Ut ut luctus arcu, vitae egestas nibh. <br><br>
          Ut sollicitudin quam sit amet enim egestas aliquet. Nunc gravida id nibh non tincidunt. Nulla id vehicula augue. Ut luctus magna non turpis hendrerit, sed tincidunt odio volutpat.
        </div>
      <div class="clearfix"></div>
    </section>
    <section class="timeline-slider left-spacer right-spacer">
        <div class="timeline-container">
            <div class="year-slider">
              <div class="swiper-container">
                <div class="swiper-wrapper">
                  <div class="swiper-slide">
                    <div class="shadowed-div">
                      2010-2011                 
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="shadowed-div">
                      2012-2013               
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="shadowed-div">
                      2014-2015               
                    </div>
                  </div>
                  <div class="swiper-slide">
                    <div class="shadowed-div">
                      2016-2017               
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
            <div class="about-us-home-new">
                <div class="timeline-slider-awards">
                    <div class="about-us-home swiper-wrapper achievements">
                        <div class="about-us-home-slider swiper-slide">
                            <div class="timeline-description">
                                <div data-show="2010">
                                    <div class="year-awards">
                                        <div class="slider-container">
                                            <div class="swiper-container">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/34.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                Most Admired Shopping Centre Launch of the Year (West) – Palladium</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/33.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2011</div>
                                                                Jury’s Special Emerging Retailer of the Year (Mall), presented to the Phoenix Mills Ltd.(Palladium)</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/32.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2011</div>
                                                                Mall Developer of the Year awarded to The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/31.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2011</div>
                                                                Developer of the year –Retail awarded to The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Add Pagination -->
                                                <div class="swiper-pagination"></div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="about-us-home-slider swiper-slide">
                            <div class="timeline-description">
                                <div data-show="2012">
                                    <div class="year-awards">
                                        <div class="slider-container">
                                            <div class="swiper-container">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/30.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2012</div>
                                                                Developer of the year awarded to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/29.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013-14</div>
                                                                Retail Development for India, by Asia-Pacific Property Awards</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/28.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013</div>
                                                                Most Admired Shopping Centre of the Year – Metro (West) presented to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/27.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013</div>
                                                                ‘Most Admired Shopping Centre of the Year, Socially Responsible’ By Asia’s Shopping Centre &amp; Mall Awards.   – presented to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/26.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013</div>
                                                                Mr. Rajendra Kalkar, Sr. Centre Director (West), has been acclaimed as one of the ‘Top 50 Most Talented Retail Professionals of India’</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/25.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013</div>
                                                                India’s Best Existing Neighborhood Shopping Mall, by Estate Avenues awarded to Palladium</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/24.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2013</div>
                                                                Shopping Center Of the Year Award presented to Palladium by Asia Retail Congress</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/23.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                Retailer of the Year (Mall) presented to The Phoenix Mills Ltd by Asia Retail Congress</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/22.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                IMAGES SHOPPING CENTRE AWARD recognized High Street Phoenix as ‘Most Admired Shopping Centre Of The Year’ – Metro (West)</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Add Pagination -->
                                                <div class="clearfix"></div>
                                                <div class="swiper-pagination"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="about-us-home-slider swiper-slide">
                            <div class="timeline-description">
                                <div data-show="2014">
                                    <div class="year-awards">
                                        <div class="slider-container">
                                            <div class="swiper-container">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/24.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                Shopping Center Of the Year Award presented to Palladium by Asia Retail Congress</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/23.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                Retailer of the Year (Mall) presented to The Phoenix Mills Ltd by Asia Retail Congress</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/22.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2010</div>
                                                                IMAGES SHOPPING CENTRE AWARD recognized High Street Phoenix as ‘Most Admired Shopping Centre Of The Year’ – Metro (West)</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Add Pagination -->
                                                <div class="clearfix"></div>
                                                <div class="swiper-pagination"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="about-us-home-slider swiper-slide">
                            <div class="timeline-description">
                                <div data-show="2016">
                                    <div class="year-awards">
                                        <div class="slider-container">
                                            <div class="swiper-container">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/21.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                RETAIL EXCELLENCE AWARDS recognized High Street Phoenix &amp; Palladium as “Shopping Centre of the Year”</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/20.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                INDIA SHOPPING CENTRE AWARDS by Images Group recognized High Street Phoenix &amp; Palladium as “Shopping Centre of the Year – Sales Per Sq. Feet”</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/19.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                INDIA SHOPPING CENTRE AWARDS by Images Group Recognized High Street Phoenix &amp; Palladium as “Shopping Centre of the Year (West) - Metro”</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/18.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                The Activation Venues Forum presented Best Premium Venue of the year to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/17.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                The Activation Venues Forum presented Best Festive Decor to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/16.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                The Activation Venues Forum presented Highest Number of footfall venue of the year to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/15.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                The Activation Venues Forum presented Best Activation Campaign to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/14.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                The Activation Venues Forum presented Best Venue for the Activation Campaign to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/13.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                Star Retailer Awards 2016 presented Regional Mall of the year – West to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/12.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                Global Marketing Excellence Awards presented Award for Marketing Excellence in Retail Sector to – The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/11.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                Global Marketing Excellence Awards presented Award for best use of Social Media in Marketing to #Oneforlove campaign – The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/10.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2016</div>
                                                                Global Safety Summit BCToad Business &amp; Skill Awards 2016 presented Safest Public Shopping Mall Award to The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/09.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most Admired Shopping Centre of the Year</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/08.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Times Retail Icon 2017-18</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/07.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most Admired Asian Shopping Mall of the Year award to The Phoenix Mills Ltd.</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/06.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Images Most Admired Shopping Centre of the Year : Metro – West - Awarded to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/05.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Images Most Admired Shopping Centre of the Year : Best Sales Per Sq. Ft. – West - Awarded to High Street Phoenix</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/04.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most Admired Shopping Centre of the year presented the award to Palladium</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/03.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most Admired Shopping Centre of the year presented the award to Palladium at Le Meridien, Singapore, Sentosa</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/02.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most admired shopping centre of the year- Socially Responsible at Le Meridien, Singapore, Sentosa</div>
                                                        </div>
                                                    </div>
                                                    <div class="swiper-slide">
                                                        <div class="slide-shadow">
                                                            <div class="advantage-img"><img src="<?php echo $base_url ?>img/awards/01.png" class="img-responsive">
                                                            </div>
                                                            <div class="advantage-description">
                                                                <div class="award-year">2017</div>
                                                                <div class="bg-award-year">2017</div>Most Admired Shopping Centre of the year to Palladium at Le Meridien, Singapore, Sentosa</div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Add Pagination -->
                                                <div class="clearfix"></div>
                                                <div class="swiper-pagination"></div>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    

    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
    </body>
</html>
