<?php include('common.php'); $page='brands'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Brands</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/brands.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="brands-header left-spacer right-spacer">
        <div class="line-header">Brands</div> 
        <div class="brands-search sm-pull-right invalid">
            <input type="text" id="search" class="" name="date" placeholder="Search" required="required">   
        </div>         
    </section>
    <section class="brands-filter left-spacer right-spacer">
        <div class="slider-nav">
            <ul>
                <li><a alt="all" class="active">all</a></li>
                <li><a alt="number">#</a></li>
                <li><a alt="a">a</a></li>
                <li><a alt="b">b</a></li>
                <li><a alt="c">c</a></li>
                <li><a alt="d">d</a></li>
                <li><a alt="e">e</a></li>
                <li><a alt="f">f</a></li>
                <li><a alt="g">g</a></li>
                <li><a alt="h">h</a></li>
                <li><a alt="i">i</a></li>
                <li><a alt="j">j</a></li>
                <li><a alt="k">k</a></li>
                <li><a alt="l">l</a></li>
                <li><a alt="m">m</a></li>
                <li><a alt="n">n</a></li>
                <li><a alt="o">o</a></li>
                <li><a alt="p">p</a></li>
                <li><a alt="q">q</a></li>
                <li><a alt="r">r</a></li>
                <li><a alt="s">s</a></li>
                <li><a alt="t">t</a></li>
                <li><a alt="u">u</a></li>
                <li><a alt="v">v</a></li>
                <li><a alt="w">w</a></li>
                <li><a alt="x">x</a></li>
                <li><a alt="y">y</a></li>
                <li><a alt="z">z</a></li>
            </ul>
        </div>
    </section>
    <section class="brands-filter-list left-spacer right-spacer">        
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide all a">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/anita-dongre.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">Anita dongre</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="javascript:void(0);" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/accessorize.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">accessorize</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="<?php echo $base_url ?>brands/aldo" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/aldo.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">aldo</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="javascript:void(0);" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/am-pm.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">am:pm</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="javascript:void(0);" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/armani-jeans.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">armani jeans</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="javascript:void(0);" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/aroma-thai-foot-spa.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">aroma thai foot spa</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all a">
                    <a href="javascript:void(0);" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/asia-kithcen-by-mainland-china.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">asia kithcen by mainland china</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all b">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/bbc.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">british brewing company</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all c">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/casa-pashma.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">casa pashma</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all c">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/coach.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">coach</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all c">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/creyate.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">creyate</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all c">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/crocs.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">crocs</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all e">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/estee-lauder.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">estee lauder</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all h">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/hunkemoller.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">hunkemoller</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all j">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/jo-malone-london.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">jo malone london</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all j">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">juicy couture</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all m">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">masaba</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all m">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">mont blanc</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all m">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">muji</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all o">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">onitsuka tiger</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all p">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">papabubble</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all r">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">ritu kumar</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all s">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">Scotch &amp; Soda</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all s">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">Selected homme</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all t">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">Tommy hilfiger</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide all z">
                    <a href="" title="">
                        <div class="filtered_brand_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/brands/juicy-couture.png" alt=""></div>
                            </div>
                        <div class="filtered_brand_info">
                            <div class="brand_name">zara</div>
                            <div class="brand_place">Skyzone level 0</div>
                        </div>
                    </a>
                </div>
            </div>            
            <div class="swiper-pagination"></div>
        </div>
        <div class="next-slide-arrows"></div>
        <div class="prev-slide-arrows"></div>
    </section>
    <section class="events-slider-container">
        <input id="events-slider" class="slider index-for-events-slider" class="swiper-range" type="text" data-slider-tooltip="hide" value="0.0" /> 
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
