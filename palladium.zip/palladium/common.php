<?php 
  $base_url= 'http://10.0.0.84/palladium/';
 ?>