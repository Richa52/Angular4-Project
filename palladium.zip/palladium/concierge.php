<?php include('common.php'); $page='concierge'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Concierge</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="nonseo relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="concierge left-spacer col-sm-6">
        <div class="line-header">Concierge</div> 
        <div class="concierge-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque nulla tortor, tincidunt sit amet sem a, tristique porta lectus. Nullam semper leo eget sollicitudin maximus.</div>      
    </section>
    <div class="clearfix"></div>
    <section class="concierge-container left-spacer right-spacer container-fluid">
        <div class="concierge-list">
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/prepaid-mobile.png">Prepaid mobile recharges
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/postpaid-bill.png">Postpaid bill payments
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/electricity-bill.png">Electricity bill payments
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/water-bill.png">Water bill payments
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/gas-bill.png">Gas bill payments
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/dth-recharge.png">DTH recharges
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/data-card.png">Data cards recharges
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/railway-tickets.png">Railways tickets booking
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/flight-tickets.png">Flight tickets booking
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/baggage.png">Baggage counter facility (non-chargeable)
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/mall-queries.png">Mall queries to customers
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/gift-wrapping.png">Gift wrapping (non chargeable)
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/money-transfers.png">Money transfers
                </div>
            </div>
            <div class="concierge-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/concierge/cheque.png">Cheque deposition
                </div>
            </div>
        </div>
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
