<?php include('common.php'); $page='contact'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Contact Us</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="nonseo relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="extras-header left-spacer">
        <div class="line-header">Contact Us</div>       
    </section>
    <section class="contact-container left-spacer right-spacer container-fluid">
        <div class="col-sm-6">
            <div class="sub-heading no-top-pad">Need support?</div>  
            <div class="site-mail"><div class="sprite bg-mail"></div>info@palladiummumbai.com</div>
            <div class="site-contact"><div class="sprite bg-call"></div>022-43339999 / 94</div>
            <div class="sub-heading">Mall Timings</div>    
            We are open on all days from 11 am to 10 pm.        
        </div>   
        <div class="col-sm-6 sm-pull-right">
            <div class="map" id="map"></div>  
            <div class="getdirection">
                <a href="http://maps.google.com/?daddr=Palladium+Lower+Parel+Mumbai&dirflg=r&travelmode=driving" target="_blank" directions="https://www.google.com/maps/place/Palladium/@18.993832,72.8231848,18.25z/data=!3m1!5s0x3be7ce8c7a97e06d:0xbbf7fd84abd813ca!4m5!3m4!1s0x3be7ce8c79e8b109:0xa69a7761c3b1cd20!8m2!3d18.9942265!4d72.8242265?hl=en-US">Get Directions ></a>
            </div>           
        </div>
        <div class="col-sm-6">
            <div class="sub-heading">contact us</div> 
                <form id="contact_details" class="form-horizontal" method="post" novalidate>
                    <div class="form-group">
                        <div class="col-sm-6 group">
                            <input type="text" id="name" name="name" class="form_fields form-control" placeholder="Name" required>
                        </div>
                        <div class="col-sm-6 group">
                            <input type="email" name="email" class="form_fields form-control" placeholder="Email" required> 
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-6 group">
                            <input type="tel" name="phone" class="form_fields form-control" placeholder="Phone" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        </div>
                        <div class="col-sm-6 group">
                            <input type="text" name="message" class="form_fields form-control" placeholder="Your Message" required> 
                        </div>
                    </div>
                    <div class="form-group submit_group">
                        <div class="col-sm-12">
                            <input class="contact_submit" type="submit" name="" value="submit">
                        </div>
                    </div>
                </form>           
        </div>
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
