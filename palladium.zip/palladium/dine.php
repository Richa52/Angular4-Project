<?php include('common.php'); $page='dine'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Dine</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/dine.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="dine-header left-spacer right-spacer">
        <div class="line-header">Dine</div>        
    </section>
    <section class="dine-filter left-spacer right-spacer">
        <div class="sub-heading">filters:</div>
        <div class="slider-nav">
            <ul>
                <li class="checkbox-filter">                              
                    <div class="squaredTwo">
                        <input type="checkbox" value="None" id="ServesAlcohol" name="check" />
                        <label for="ServesAlcohol"></label>
                    </div>
                    <label class="checkbox-label" for="ServesAlcohol">Serves Alcohol</label>
                </li> 
                <li class="checkbox-filter">                              
                    <div class="squaredTwo">
                        <input type="checkbox" value="None" id="HappyHours" name="check" />
                        <label for="HappyHours"></label>
                    </div>
                    <label class="checkbox-label" for="HappyHours">Happy Hours</label>
                </li> 
                <li class="checkbox-filter">                              
                    <div class="squaredTwo">
                        <input type="checkbox" value="None" id="KidFriendly" name="check" />
                        <label for="KidFriendly"></label>
                    </div>
                    <label class="checkbox-label" for="KidFriendly">Kid Friendly</label>
                </li>  
                <li class="checkbox-filter">                              
                    <div class="squaredTwo">
                        <input type="checkbox" value="None" id="OnlineReservation" name="check" />
                        <label for="OnlineReservation"></label>
                    </div>
                    <label class="checkbox-label" for="OnlineReservation">Online Reservation</label>
                </li>                
            </ul>
        </div>
    </section>
    <section class="dine-filter-list left-spacer right-spacer">        
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <a href="<?php echo $base_url ?>dine/indigo-delicatessan" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-01.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">Indigo Delicatessan</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-02.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">pa pa ya</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-03.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">british brewing company</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-04.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">moshe's</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-01.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">Indigo Delicatessan</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-02.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">pa pa ya</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-03.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">british brewing company</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
                <div class="swiper-slide">
                    <a href="javascript:void(0)" title="">
                        <div class="filtered_dine_img">
                            <div class="img_align_div">
                                <img src="<?php echo $base_url ?>img/dine/dine-04.png" alt=""></div>
                            </div>
                        <div class="filtered_dine_info">
                            <div class="dine_name">moshe's</div>
                            <div class="dine_place">Palladium level 01</div>
                            <div class="dine_time">9 am to 1 am</div>
                        </div>
                    </a>
                </div>
            </div>            
            <div class="swiper-pagination"></div>
        </div>
        <div class="next-slide-arrows"></div>
        <div class="prev-slide-arrows"></div>
    </section>
    <section class="events-slider-container">
        <input id="events-slider" class="slider index-for-events-slider" class="swiper-range" type="text" data-slider-tooltip="hide" value="0.0" /> 
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
