<?php include('common.php'); $page='media'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Downloads</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/media.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="media-header left-spacer right-spacer">
        <div class="line-header">Media</div>       
    </section>
    <section class="media-menu left-spacer right-spacer">        
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><a href="<?php echo $base_url ?>media">Media</a></div>
                    <div class="swiper-slide"><a href="<?php echo $base_url ?>press">press releases</a></div>
                    <div class="swiper-slide"><a href="<?php echo $base_url ?>queries">queries</a></div>
                    <div class="swiper-slide active"><a href="<?php echo $base_url ?>downloads">downloads</a></div>
                </div>
            </div>    
    </section>
    <section class="downloads left-spacer right-spacer">
        <div class="sub-heading">media kit</div>
        <div class="download-kit">
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Brand Kit</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Media Kit</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
            <div class="col-sm-3">
                <a class="" href="<?php echo $base_url ?>img/download.pdf" download="">Lorem ipsum</a>                
            </div>
        </div>

    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
