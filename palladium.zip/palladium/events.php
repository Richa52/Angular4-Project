<?php include('common.php'); $page='events'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Events</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/events.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="events-header left-spacer">
        <div class="line-header">Events</div> 
        <div class="events-search sm-pull-right invalid">
            <input type="text" id="search" class="" name="date" placeholder="Search" required="required">   
        </div>   
        <div class="events-filter">
            <div class="fancy-dropdown-contain">
                <div class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                Type of Event<span class="caret"></span>
                </div>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                  <li><a data-value="Lorem ipsum">Lorem ipsum</a></li>
                </ul>
            </div> 
            <div class="events-date-picker"><input type="text" id="datepicker" name="date" placeholder="Start Date"><span class="caret"></span></div>
        </div>       
    </section>
    <section class="events-slider-container left-spacer">
        <section class="events sm-pull-right col-sm-9">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-02.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-03.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-02.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-03.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-02.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-03.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-01.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-02.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/events/events-03.png" class="img-responsive"></div>
                </div>
            </div>
        </section>
        <section class="events-contain col-sm-3">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium 01</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="<?php echo $base_url ?>events/art-at-palladium" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium 02</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium 03</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium 04</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="<?php echo $base_url ?>events/art-at-palladium" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="event-details">
                            <div class="event-name">Art at Palladium</div>
                            <div class="event-location">Art at Palladium</div>  
                            <div class="event-time">15<sup>th</sup> March, 2017</div>  
                            <div class="event-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin feugiat auctor volutpat. Aliquam lorem nulla, elementum non viverra eu.</div>   
                            <a href="javascript:void(0);" class="know-more-btn">know more</a>                       
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="clearfix"></div>      
    </section>
    <section class="events-slider-container">
        <input id="events-slider" class="slider index-for-events-slider" class="swiper-range" type="text" data-slider-tooltip="hide" value="0.0" /> 
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
