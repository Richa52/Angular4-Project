<script type="text/javascript" src='<?php echo $base_url ?>js/jquery-1.11.2.js'></script>
    <script>window.jQuery || document.write('<script src="<?php echo $base_url ?>js/jquery-1.11.2.js"><\/script>')</script>
    <script type="text/javascript" src='<?php echo $base_url ?>js/bootstrap.min.js'></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery-ui.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/common.js"></script>
<?php if($page == 'home' || $page == 'about'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/TweenMax.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/main.js"></script>
<?php }?>
<?php if($page == 'events'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/plugins.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/TweenMax.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/bootstrap-slider.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery-ui.js"></script> 
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/events.js"></script>
<?php }?>
<?php if($page == 'brands'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/TweenMax.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/bootstrap-slider.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/brands.js"></script>
<?php }?>
<?php if($page == 'dine'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/plugins.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/TweenMax.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/bootstrap-slider.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/dine.js"></script>
<?php }?>
<?php if($page == 'media'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/plugins.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/TweenMax.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/bootstrap-slider.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery-ui.js"></script> 
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/media.js"></script>
<?php }?>
<?php if($page == 'gifts'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
<?php }?>
<?php if($page == 'awards'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/swiper.min.js"></script>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery-ui.js"></script> 
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <!-- <script type="text/javascript" src="<?php echo $base_url ?>js/timeline.js"></script> -->
<?php }?>
<?php if($page == 'contact'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBMfo1ImNYkUU_cH3KEo1R986VesNxLp6k&callback=initMap" type="text/javascript"></script>
    <script src="<?php echo $base_url ?>js/map.js"></script>
<?php }?>
<?php if($page == 'tandc' || $page == 'contact' || $page == 'gifts' || $page == 'awards' || $page == 'concierge'){ ?>
    <script type="text/javascript" src="<?php echo $base_url ?>js/extras.js"></script>
<?php }?>
<?php if($page == 'delivery'||$page == 'signin'||$page == 'payment'||$page == 'product'){ ?>    
    <script src="<?php echo $base_url ?>js/jquery.validate.min.js"></script>
    <script src="<?php echo $base_url ?>js/login.js"></script>
<?php }?>