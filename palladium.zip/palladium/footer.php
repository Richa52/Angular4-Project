    <footer class="rel-footer site-footer">
      <section class="newsletter" style="display: none;">
        <h3>subscribe to newsletter</h3>
        <div class="email-box">
          <input id="newsletter" type="Email" placeholder="Enter Email Id" name="newsletter">
          <button type="submit" onclick="send_newsletter(this);">&rarr;</button>
            <span class="newsletter-error"></span>
        </div>
      </section> 
      <section class="seo-content">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer placerat porttitor rutrum. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut convallis, nisi nec ultricies accumsan, augue quam accumsan tellus, vitae sollicitudin tortor nisl vitae orci. Aliquam interdum tincidunt feugiat. Nunc suscipit ipsum sit amet finibus imperdiet. Integer at congue magna. Quisque rhoncus dignissim vehicula. Suspendisse vestibulum tortor quis hendrerit aliquam. Suspendisse in nibh eros. Donec rutrum libero eget rhoncus ornare. Curabitur id pulvinar eros. Etiam convallis imperdiet imperdiet. Duis imperdiet vehicula finibus. Maecenas magna ante, sagittis bibendum libero quis, fermentum hendrerit enim. Aenean iaculis nisl eu nisl vestibulum, ac laoreet justo elementum. Suspendisse diam augue, ullamcorper et porttitor eget, laoreet ut neque. Nunc arcu massa, pulvinar scelerisque fermentum ut, auctor eu dolor. Nullam auctor, orci et suscipit rutrum, ex sapien tempor tortor, eget efficitur lectus mauris mattis magna. Nam tellus lacus, interdum id congue ac, facilisis ut quam. Cras ut magna sed tortor ultricies facilisis sed vel risus. In consequat est a risus hendrerit, ac sagittis erat rutrum. Proin quis hendrerit nisl. Donec volutpat, urna et egestas maximus, sapien turpis pellentesque tellus, sit amet laoreet enim augue in elit. In posuere metus nibh, id lacinia purus vulputate.
      </section>     
      <div class="footer_links">
        <span class="copyright">&copy; All right reserved&nbsp;&nbsp;|&nbsp;&nbsp;copyright 2017</span>
        <ul class="footer_sitemap">
          <li><a href="<?php echo $base_url; ?>contact" title="">contact</a></li>
          <li><a href="javascript:void(0)" title="">about</a></li>
          <li><a href="javascript:void(0)" title="">press</a></li>
          <li><a href="javascript:void(0)" title="">careers</a></li>
          <li><a href="<?php echo $base_url ?>img/Tacker_Of_Lab_report.xlsx" target="_blank" title="">environ parameters</a></li>
          <li><a href="javascript:void(0)" title="" class="show_newsletter" onclick="showNewsletter();">subscribe to newsletter</a></li>
        </ul>
        <span class="media_links">
          <a href="javascript:void(0)" class="sprite bg-facebook"></a>
          <a href="javascript:void(0)" class="sprite bg-twitter"></a>
          <a href="javascript:void(0)" class="sprite bg-instagram"></a>
        </span>
      </div>
    </footer>