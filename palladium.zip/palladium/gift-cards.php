<?php include('common.php'); $page='gifts';  ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Gifts Cards</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <?php include('header.php'); ?>   


    <section class="menu-gap"></section>

    <section class="gifts-advantages-slider left-spacer right-spacer">
      <div class="line-header">Phoenix Gift Card</div>
      <div class="gift-description">Gifting is now very convenienat. Take your shopping experience at Phoenix to a whole other level!</div>
      <div class="slider-container">
        <div class="sub-header">Advantages</div>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="shadowed-div">
                    <div class="advantage-img"><img src="<?php echo $base_url ?>img/gifts-advantage-01.png" class="img-responsive"></div>
                    <div class="advantage-description">Available for purchase at all Phoenix malls</div>                  
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="shadowed-div">
                    <div class="advantage-img"><img src="<?php echo $base_url ?>img/gifts-advantage-02.png" class="img-responsive"></div>
                    <div class="advantage-description">Can be used across any store at all Phoenix Malls</div>                  
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="shadowed-div">
                    <div class="advantage-img"><img src="<?php echo $base_url ?>img/gifts-advantage-03.png" class="img-responsive"></div>
                    <div class="advantage-description">Provides great flexibility and experience for self-purchase and gifting</div>                  
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="shadowed-div">
                    <div class="advantage-img"><img src="<?php echo $base_url ?>img/gifts-advantage-04.png" class="img-responsive"></div>
                    <div class="advantage-description">Powered by Visa and operates like any normal Debit/Credit card</div>                  
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="shadowed-div">
                    <div class="advantage-img"><img src="<?php echo $base_url ?>img/gifts-advantage-05.png" class="img-responsive"></div>
                    <div class="advantage-description">Can be loaded for amounts up to Rs. 50,000/-</div>                  
                  </div>
                </div>
            </div>
            <!-- Add Pagination -->
            <div class="clearfix"></div>
            <div class="swiper-pagination"></div>
        </div>
      </div>
      <div class="text-center"><a class="home-delivered-button" data-toggle="modal" href='#gift_card'>Get the Phoenix Gift Card <br class="visible-xs">home delivered</a></div>
      <div class="modal fade" id="gift_card">
        <div class="modal-dialog">
          <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <div class="modal-header">
            </div>
            <div class="modal-body">
              <div class="recommend_text">Send us your details</div>
              <div class="col-sm-12 form_div">
                <form id="gift_card_form" class="form-horizontal" method="post">
                  <div class="col-sm-12">
                    <input type="text" class="form_fields form-control" name="name" value="" placeholder="Name">
                  </div>
                  <div class="col-sm-12">
                    <input type="tel" class="form_fields form-control" name="number" value="" placeholder="Contact Number" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                  </div>
                  <div class="col-sm-12">
                    <input type="email" class="form_fields form-control" name="email" value="" placeholder="Email ID">
                  </div>
                  <div class="col-sm-12">
                    <input type="text" class="form_fields form-control" name="address" value="" placeholder="Address">
                  </div>
                  <div class="col-sm-12">
                    <input class="gift_submit" type="submit" name="" value="Submit">
                  </div>
                </form>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
    </section>

    <section class="faq left-spacer right-spacer">
      <h3 class="header-text">Frequently Asked Questions</h3>
      <ul class="col-sm-6" id="faq">
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq" href="#faq1" aria-expanded="false">Where can I buy the Phoenix Gift Card? <i></i></a>
          <div id="faq1" class="panel-collapse collapse">
              <div class="panel-body">
                  You can purchase The Phoenix gift card at any of the Phoenix Malls located at Lower Parel, Kurla, Bangalore, Chennai, Hyderabad, Bareily and Lucknow.
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq" href="#faq2" aria-expanded="false">How does the card work? <i></i></a>
          <div id="faq2" class="panel-collapse collapse">
              <div class="panel-body">
                  Every time the gift card is used, the purchase amount is deducted automatically from the card balance. When you swipe the card at any POS machine, the machine will prompt for PIN. Enter your Gift card PIN details to complete the transaction.   
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq" href="#faq3" aria-expanded="false">Where can I pay for the Phoenix Gift Card? What are the payment methods available? <i></i></a>
          <div id="faq3" class="panel-collapse collapse">
              <div class="panel-body">
                  -NEFT/RTGS <br>
                  -UPI <br>
                  -Bharat QR <br>
                  -PayTM <br>
                  -IMPS <br>
                  -MMID <br>
                  -Debit/Credit Card <br>
                  -Bank Transfer <br>
                  -Cash 
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq" href="#faq4" aria-expanded="false">What value can I load on the gift card? <i></i></a>
          <div id="faq4" class="panel-collapse collapse">
              <div class="panel-body">
                  The card can be loaded with a value of upto Rs. 50,000 /-  
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq" href="#faq5" aria-expanded="false">Is it transferable? <i></i></a>
          <div id="faq5" class="panel-collapse collapse">
              <div class="panel-body">
                  Yes. However, the beneficiary details are required in the form of a KYC as all communication regarding their gift card activation and transactions will be sent to their contact details in future.   
              </div>
          </div>
        </li>
      </ul>
      <ul class="col-sm-6" id="faq2">
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq2" href="#faq6" aria-expanded="false">Are there any restrictions on the acceptance of the cards? <i></i></a>
          <div id="faq6" class="panel-collapse collapse">
              <div class="panel-body">
                  No. The card is valid across all stores at all Phoenix malls  
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq2" href="#faq7" aria-expanded="false">What is the validity of the card? <i></i></a>
          <div id="faq7" class="panel-collapse collapse">
              <div class="panel-body">
                  The card will have a minimum validity of 6 months
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq2" href="#faq8" aria-expanded="false">What are the safety and security features of the card? <i></i></a>
          <div id="faq8" class="panel-collapse collapse">
              <div class="panel-body">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam rutrum facilisis nunc. Maecenas quis eros in ante vehicula dictum in eget lectus. Curabitur a lorem lectus. Vivamus gravida vel purus a pretium. Ut lobortis nunc in lectus convallis, vitae rutrum enim ornare. Orci varius natoque penatibus et magnis dis parturient.
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq2" href="#faq9" aria-expanded="false">Is a KYC required? <i></i></a>
          <div id="faq9" class="panel-collapse collapse">
              <div class="panel-body">
                  Yes. KYC is compulsory in order to purchase a Phoenix Gift Card. Know your customer (KYC) is a mandatory set of identity and address proof documents as prescribed by the Reserve Bank of India (RBI) <br>
                  Any one of the following self-attested documents can be submitted as proof of identity:
                  Passport
                  PAN Card
                  Voter’s identity Card
                  Aadhaar Card No.

                  Any one of the following self-attested documents that can be submitted as proof of address:
                  Passport
                  Voter’s Identity Card
                  Aadhaar Card No. 
              </div>
          </div>
        </li>
        <li class="panel">
          <a class="faq-head" data-toggle="collapse" data-parent="#faq2" href="#faq10" aria-expanded="false">Can an expired gift card be exchange for a new gift card? <i></i></a>
          <div id="faq10" class="panel-collapse collapse">
              <div class="panel-body">
                  No, an expired card cannot be exchanged for a new gift card. 
                  -Add external link .pdf for extended FAQs and processes (the doc shared earlier)
                  -Add external .pdf for Terms and Conditions for the Gift Card (Will share these)
                  -Add link for ‘Get the Phoenix Gift Card home delivered’ (will share data for this separately too)
              </div>
          </div>
        </li>
      </ul>
    </section>

    <section class="know-more-about">
      want to know more about Phoenix Gift Cards? read the <a  href="<?php echo $base_url ?>img/HSP-Gift-Card-Welcome-letter-T&C.pdf" download>Terms &amp; conditions</a> and <a  href="<?php echo $base_url ?>img/Phoenix-Gift-Card-FAQs.pdf" download>FAQs &amp; processes</a>
    </section>

    

    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
    </body>
</html>
