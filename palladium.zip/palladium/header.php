<nav class="navbar navbar-fixed-top main-navbar" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header main-header">
      <a class="navbar-brand site-logo" style="/* padding: 0; */ height: auto;" href="<?php echo $base_url ?>"><img src="<?php echo $base_url ?>img/logo.svg" class="img-responsive color-logo"></a>
      <ul class="main-top-menu hidden-xs">
        <li class="<?php if($page == 'brands'){echo 'active'; }?>"><a href="<?php echo $base_url ?>brands">brands</a></li>
        <li class="<?php if($page == 'events'){echo 'active'; }?>"><a href="<?php echo $base_url ?>events">events</a></li>
        <li class="<?php if($page == 'dine'){echo 'active'; }?>"><a href="<?php echo $base_url ?>dine">dine</a></li>
        <li class="<?php if($page == 'contact'){echo 'active'; }?>"><a href="<?php echo $base_url ?>contact">contact</a></li>
      </ul>
      <div class="menu-button"></div>
    </div>
  </div>
</nav>
<div id="full-menu" class="sidenav">
  <div class="container-fluid" style="display: none;">
    <div class="full-menu-header">
      <a class="palladium-logo" href="<?php echo $base_url ?>"><img src="<?php echo $base_url ?>img/logo.svg" class="img-responsive"></a>
    </div>
  </div>
  
  <div class="menu-container" style="display: none;">
    <div class="menu-row">
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>brands">Brands</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>events">Events</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>dine">Dine</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>about-us">About</a></div>
    </div>
    <div class="menu-row">
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>media">Media</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>gift-cards">Gift Cards</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>awards">Awards</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>concierge">Concierge</a></div>
    </div>
    <div class="menu-row">
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>parking">Parking</a></div>
      <div class="col-sm-3 div-cell"><a href="<?php echo $base_url ?>contact">Contact</a></div>
      <div class="col-sm-3 div-cell gotham"><a href="javascript:void(0);"><div class="sprite bg-mail"></div>info@highstreetphoenix.com</a></div>
      <div class="col-sm-3 div-cell gotham"><a href="javascript:void(0);"><div class="sprite bg-call"></div>022 4333 9994</a></div>
    </div>
  </div>

  <footer class="rel-footer" style="display: none;">
    <section class="newsletter" style="display: none;">
      <h3>subscribe to newsletter</h3>
      <div class="email-box">
        <input id="newsletter" type="Email" placeholder="Enter Email Id" name="newsletter">
        <button type="submit" onclick="send_newsletter(this);">&rarr;</button>
          <span class="newsletter-error"></span>
      </div>
    </section>     
    <div class="footer_links">
      <span class="copyright">&copy; All right reserved&nbsp;&nbsp;|&nbsp;&nbsp;copyright 2017</span>
      <ul class="footer_sitemap">
        <li><a href="<?php echo $base_url; ?>contact" title="">contact</a></li>
        <li><a href="<?php echo $base_url; ?>about-us" title="">about</a></li>
        <li><a href="<?php echo $base_url; ?>press" title="">press</a></li>
        <li><a href="javascript:void(0)" title="">careers</a></li>
        <li><a href="<?php echo $base_url ?>img/Tacker_Of_Lab_report.xlsx" target="_blank" title="">environ parameters</a></li>
        <li><a href="javascript:void(0)" title="" class="show_newsletter" onclick="showNewsletter();">subscribe to newsletter</a></li>
      </ul>
      <span class="media_links">
        <a href="javascript:void(0)" class="sprite bg-facebook"></a>
        <a href="javascript:void(0)" class="sprite bg-twitter"></a>
        <a href="javascript:void(0)" class="sprite bg-instagram"></a>
      </span>
    </div>
  </footer>
</div>
<div class="button_container" id="toggle">
  <span class="top"></span>
  <span class="middle"></span>
  <span class="bottom"></span>
</div> 
