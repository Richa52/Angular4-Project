<?php include('common.php'); $page='home'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/main.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="">
      <div class="home-slider">
        <div class="slider-wrapper">
            <div class="main-content">
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>   
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>   
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>   
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>   
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>   
                <div class="div-slide-content">                    
                    <div class="bg-main-text"><h1>Luxuriously Yours</h1>Luxuriously Yours</div>
                    <div class="description-text">High Street Phoenix has truly put Mumbai on a pedestal with Palladium, the city's first luxury and premium retail and entertainment destination.</div>
                </div>                
            </div>
            <div class="main-slider">
              <div id="slideshowHolder" active-slider="1" style="position: relative;">
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img1' />
                </div>
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img2' />
                </div>
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img3' />
                </div>
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img1' />
                </div>
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-01.png' alt='img2' />
                </div>
                <div class="div-slide"><img src='<?php echo $base_url ?>img/banner-02.png' alt='img3' />
                </div>
              </div>
              <div class="timer"></div>
            </div>
            
        </div>
        <div class="pagination"></div>  
      </div>
      <div class="clearfix"></div>
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
