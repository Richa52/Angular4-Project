<?php include('common.php'); $page='dine'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Dine</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/dine.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="event-header event-individual left-spacer right-spacer">
        <div class="line-header">Events</div>       
    </section>
    <section class="dine-content">
        <div class="col-sm-6 event-image-slider">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/dine/dine-01-large.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/dine/dine-01-large.png" class="img-responsive"></div>
                    <div class="swiper-slide"><img src="<?php echo $base_url ?>img/dine/dine-01-large.png" class="img-responsive"></div>
                </div>
                <div class="swiper-pagination"></div>
            </div>           
        </div>
        <div class="col-sm-6 back-to-event description-spacer"><a href="<?php echo $base_url ?>dine">back</a></div>         
        <div class="col-sm-6 event-details description-spacer">
            <div class="event-name">Indigo Delicatessan</div>
            <div class="event-location"><div class="sprite bg-location"></div>Palladium level 01</div>
            <div class="event-time"><div class="sprite bg-time"></div>9 am To 1 am</div>
            <div class="event-contact"><div class="sprite bg-call"></div>022-436-66666</div>
        </div> 
        <div class="col-sm-6 event-description description-spacer">
            The food speaks for itself, as it surprises the palate with an ever-changing menu of eclectic modern European cuisine. The aura of hospitality, restrained elegance and refinement is punctuated by sun-lit spaces and chic interiors.  <br><br>
            One of India's finest restaurants, Indigo was started by Rahul Akerkar, driven by his passion for food, warm hospitality and an eye for detail. To spend a few indulgent moments here is to experience the best of what modern India has to offer.
        </div>    
    </section> 
    <div class="clearfix"></div> 
    <section class="reserve-table">        
        <div class="container reserve-table-form description-spacer">
            <div class="">
                <div class="booking-head">reserve a table</div>

                <form id="booking_details" class="form-horizontal" method="post" novalidate>
                    <div class="form-group">
                        <div class="col-sm-4 group">
                            <input type="text" id="name" name="name" class="form_fields form-control" placeholder="Name" required>
                        </div>
                        <div class="col-sm-4 group">
                            <div class="position-r">
                                <input type="text" id="datepicker" name="date" class="form_fields form-control" placeholder="Date" required>
                                <span class="caret"></span>
                            </div>
                        </div>
                        <div class="col-sm-4 group">
                            <div class="time_dropdown dropdown fancy-dropdown-contain">
                              <input type="text" class="dropdown-toggle form_fields reserve_time form-control" name="time" placeholder="Time" required data-toggle="dropdown" readonly="readonly">
                              <span class="caret"></span>
                              <ul class="dropdown-menu">
                                <li><a class="reserve_at" for="9:00 AM" href="javascript:void(0)">9:00 AM</a></li>
                                <li><a class="reserve_at" for="9:30 AM" href="javascript:void(0)">9:30 AM</a></li>
                                <li><a class="reserve_at" for="10:00 AM" href="javascript:void(0)">10:00 AM</a></li>
                                <li><a class="reserve_at" for="10:30 AM" href="javascript:void(0)">10:30 AM</a></li>
                                <li><a class="reserve_at" for="11:00 AM" href="javascript:void(0)">11:00 AM</a></li>
                                <li><a class="reserve_at" for="11:30 AM" href="javascript:void(0)">11:30 AM</a></li>
                                <li><a class="reserve_at" for="12:00 PM" href="javascript:void(0)">12:00 PM</a></li>
                                <li><a class="reserve_at" for="12:30 PM" href="javascript:void(0)">12:30 PM</a></li>
                                <li><a class="reserve_at" for="1:00 PM" href="javascript:void(0)">1:00 PM</a></li>
                                <li><a class="reserve_at" for="1:30 PM" href="javascript:void(0)">1:30 PM</a></li>
                                <li><a class="reserve_at" for="2:00 PM" href="javascript:void(0)">2:00 PM</a></li>
                                <li><a class="reserve_at" for="2:30 PM" href="javascript:void(0)">2:30 PM</a></li>
                                <li><a class="reserve_at" for="3:00 PM" href="javascript:void(0)">3:00 PM</a></li>
                                <li><a class="reserve_at" for="3:30 PM" href="javascript:void(0)">3:30 PM</a></li>
                                <li><a class="reserve_at" for="4:00 PM" href="javascript:void(0)">4:00 PM</a></li>
                                <li><a class="reserve_at" for="4:30 PM" href="javascript:void(0)">4:30 PM</a></li>
                                <li><a class="reserve_at" for="5:00 PM" href="javascript:void(0)">5:00 PM</a></li>
                                <li><a class="reserve_at" for="5:30 PM" href="javascript:void(0)">5:30 PM</a></li>
                                <li><a class="reserve_at" for="6:00 PM" href="javascript:void(0)">6:00 PM</a></li>
                                <li><a class="reserve_at" for="6:30 PM" href="javascript:void(0)">6:30 PM</a></li>
                                <li><a class="reserve_at" for="7:00 PM" href="javascript:void(0)">7:00 PM</a></li>
                                <li><a class="reserve_at" for="7:30 PM" href="javascript:void(0)">7:30 PM</a></li>
                                <li><a class="reserve_at" for="8:00 PM" href="javascript:void(0)">8:00 PM</a></li>
                                <li><a class="reserve_at" for="8:30 PM" href="javascript:void(0)">8:30 PM</a></li>
                                <li><a class="reserve_at" for="9:00 PM" href="javascript:void(0)">9:00 PM</a></li>
                                <li><a class="reserve_at" for="9:30 PM" href="javascript:void(0)">9:30 PM</a></li>
                                <li><a class="reserve_at" for="10:00 PM" href="javascript:void(0)">10:00 PM</a></li>
                                <li><a class="reserve_at" for="10:30 PM" href="javascript:void(0)">10:30 PM</a></li>
                                <li><a class="reserve_at" for="11:00 PM" href="javascript:void(0)">11:00 PM</a></li>
                              </ul>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-4 group">
                            <input type="tel" name="people" class="form_fields form-control" placeholder="Number of people">
                        </div>
                        <div class="col-sm-4 group">
                            <input type="tel" name="phone" class="form_fields form-control" placeholder="Contact Number" required onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                        </div>
                        <div class="col-sm-4 group">
                            <input type="tel" name="requests" class="form_fields form-control" placeholder="Additional Requests" >
                        </div>
                    </div>
                    <div class="form-group submit_group">
                        <div class="col-sm-12">
                            <input class="booking_submit" type="submit" name="" value="stay updated">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <section class="related-dining container">
        <div class="related-dining-head">Related Dining</div>
            <div class="related-dining-wrapped">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/dine/related-dine-01.png" class="img-responsive"></div>
                            <div class="event-name">moshe's</div>
                            <div class="event-place">Palladium Level 0</div>
                            <div class="event-time">11 am to 11.30 pm</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/dine/related-dine-02.png" class="img-responsive"></div>
                            <div class="event-name">pa pa ya</div>
                            <div class="event-place">Palladium Level 3</div>
                            <div class="event-time">12 Noon to 12.30 am</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/dine/related-dine-03.png" class="img-responsive"></div>
                            <div class="event-name">british brewing company</div>
                            <div class="event-place">Palladium Level 3</div>
                            <div class="event-time">12 Noon to 12.30 am</div>
                        </div>
                        <div class="swiper-slide">
                            <div class="event-img"><img src="<?php echo $base_url ?>img/dine/related-dine-04.png" class="img-responsive"></div>
                            <div class="event-name">asia kitchen by mainland china</div>
                            <div class="event-place">Palladium Level 4</div>
                            <div class="event-time">12 Noon to 11.30 am </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>    
                </div>             
                <div class="next-slide-arrows"></div>
                <div class="prev-slide-arrows"></div>
                
            </div>
    </section>   
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
