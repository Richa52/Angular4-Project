var slider_length = Math.round($('.brands-filter-list .swiper-slide').length / 2);
var tick_values = [];

function responsive_triggers_brands() {
    var slider_btn_width = $('section.events-slider-container .slider.slider-horizontal .slider-track').width() / slider_length;
    $('section.events-slider-container .slider.slider-horizontal .slider-handle').css({
        'width': slider_btn_width,
        'margin-left': -(slider_btn_width / 2)
    });
    if ($('body').hasClass('relative')) {
        if ($('footer.site-footer').hasClass('rel-footer')) {
            if (window.innerHeight > document.body.offsetHeight) {
                $('footer.site-footer').addClass('fixed-footer');
                $('footer.site-footer').removeClass('rel-footer');
            } else {
                $('footer.site-footer').addClass('rel-footer');
                $('footer.site-footer').removeClass('fixed-footer');
            }
        } else {
            if (window.innerHeight > (document.body.offsetHeight) + $('footer.site-footer').height()) {
                $('footer.site-footer').addClass('fixed-footer');
                $('footer.site-footer').removeClass('rel-footer');
            } else {
                $('footer.site-footer').addClass('rel-footer');
                $('footer.site-footer').removeClass('fixed-footer');
            }
        }
    }
}

function pagination_events() {
    if ($('.brands-filter-list .next-slide-arrows.swiper-button-disabled').length > 0) {
        if ($('.brands-filter-list .prev-slide-arrows.swiper-button-disabled').length > 0) {
            if ($(window).width() > mobile_breakpoint) {
                $('section.events-slider-container .slider.slider-horizontal').hide();
                $('.brands-filter-list .next-slide-arrows').hide();
                $('.brands-filter-list .prev-slide-arrows').hide();
            } else {
                $('.brands-filter-list .next-slide-arrows').hide();
                $('.brands-filter-list .prev-slide-arrows').hide();
            }
        }
    } else {
        if ($(window).width() > mobile_breakpoint) {
            $('section.events-slider-container .slider.slider-horizontal').show();
            $('.brands-filter-list .next-slide-arrows').hide();
            $('.brands-filter-list .prev-slide-arrows').hide();
        } else {
            $('.brands-filter-list .next-slide-arrows').show();
            $('.brands-filter-list .prev-slide-arrows').show();
        }
    }
}

function brands_swiper_init() {
    var brands_swiper = new Swiper('.brands-filter-list .swiper-container', {
        slidesPerView: 3,
        slidesPerColumn: 2,
        paginationClickable: true,
        spaceBetween: 30,
        loop: false,
        nextButton: '.brands-filter-list .next-slide-arrows',
        prevButton: '.brands-filter-list .prev-slide-arrows',
        breakpoints: {
            520: {
                slidesPerView: 2,
                slidesPerColumn: 2,
                spaceBetween: 30,
            },
            768: {
                slidesPerView: 3,
                slidesPerColumn: 2,
                spaceBetween: 30,
            },
            1100: {
                slidesPerView: 3,
                slidesPerColumn: 2,
                spaceBetween: 30
            },
            1500: {
                slidesPerView: 5,
                slidesPerColumn: 2,
                spaceBetween: 50
            },
            1700: {
                slidesPerView: 5,
                slidesPerColumn: 2,
                spaceBetween: 70
            },
            3000: {
                slidesPerView: 6,
                slidesPerColumn: 2,
                spaceBetween: 20
            },
        },
        onSlideChangeEnd: function(swiper) {
            $(".index-for-events-slider").bootstrapSlider('setValue', swiper.realIndex);
        }
    });
    pagination_events();
}

$(window).resize(function() {
    responsive_triggers_brands();
    pagination_events();
});
$(document).on('ready', function() {
    responsive_triggers_brands();
    $("#search").on('keyup focus', function() {
        if ($('#search').is(":invalid")) {
            $(this).parent().addClass('invalid');
        } else {
            $(this).parent().removeClass('invalid');
        }
    });
    $('.brands-filter-list .swiper-no-results-slide').hide();
    brands_swiper_init();
    $("section.brands-filter .slider-nav>ul>li>a").on('click', function() {
        $('section.brands-filter .slider-nav>ul>li>a').removeClass('active');
        $(this).addClass('active');
    });
    var brands_swiper = new Swiper('.brands-image .swiper-container', {
        slidesPerView: 1,
        pagination: '.brands-image .swiper-pagination',
        paginationClickable: true,
        spaceBetween: 20,
        loop: true,
    });
    for (var i = 0; i < slider_length; i++) {
        tick_values.push(i);
    }
    $(".index-for-events-slider").bootstrapSlider({
        ticks: tick_values,
        step: 0.1,
        value: 0,
        ticks_tooltip: false,
    });
    if ($(window).width() > mobile_breakpoint) {
        if ($(".index-for-events-slider").length > 0) {
            $(".index-for-events-slider").bootstrapSlider().on('slideStop', function(ev) {
                var current_value = Math.round($('.index-for-events-slider').data('bootstrapSlider').getValue());
                $(".index-for-events-slider").bootstrapSlider('setValue', current_value);
                var brands_swiper = document.querySelector('.brands-filter-list .swiper-container').swiper;
                brands_swiper.slideTo(current_value);
            });
        }
    }
});