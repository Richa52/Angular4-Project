var mobile_breakpoint = 768;

function openNav() {
    $('#full-menu').toggleClass('open');
    $('body').css('overflow', 'hidden');
    setTimeout(function() {
        $('#full-menu .container-fluid').fadeIn();
        $('#full-menu .menu-container').fadeIn();
        $('#full-menu footer').fadeIn();
    }, 500);
}
$('#toggle').click(function() {
    $(this).toggleClass('active');
    $('body').toggleClass('open-menu');
    /*$('#overlay').toggleClass('open');
    $('.overlay-menu .site-logo').fadeToggle();*/
    $('#full-menu').toggleClass('open');
    // $('body').css('overflow', 'hidden');
    if(!$(this).hasClass('active')){
        $('#full-menu .container-fluid').fadeOut();
        $('#full-menu .menu-container').fadeOut();
        $('#full-menu footer').fadeOut();
    }else{
        setTimeout(function() {
            $('#full-menu .container-fluid').fadeToggle();
            $('#full-menu .menu-container').fadeToggle();
            $('#full-menu footer').fadeToggle();
        }, 500);        
    }
});

function closeNav() {
    $('#full-menu').toggleClass('open');
    $('body').css('overflow', '');
    $('#full-menu .container-fluid').fadeOut();
    $('#full-menu .menu-container').fadeOut();
    $('#full-menu footer').fadeOut();
}

function showNewsletter() {
    var footer_height = $('.footer_links').outerHeight();
    $('section.newsletter').css('bottom', footer_height);
    $('section.newsletter').slideToggle({
        direction: "up"
    }, 300);
}

function send_newsletter(here) {
    var email = $("#newsletter").val();
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email === '') {
        $(".email-box").addClass("error");
        $(".newsletter-error").html("Incorrect email. Please try again.");
    } else if (email.match(mailformat)) {
        $(".email-box").removeClass("error");
        $(".newsletter-error").html("");
    } else {
        $(".email-box").addClass("error");
        $(".newsletter-error").html("Incorrect email. Please try again.");
    }
}

function responsive_triggers() {
    if ($(window).width() > mobile_breakpoint) {
        $('.site-footer .footer_links').append($('.site-footer .media_links'));
        $('.sidenav .footer_links').append($('.sidenav .media_links'));
    } else {
        $('.site-footer .footer_links').prepend($('.site-footer .media_links'));
        $('.sidenav .footer_links').prepend($('.sidenav .media_links'));
    }
    $('section.main-navigate').css('top', ($('.navbar.navbar-fixed-top').innerHeight()));
    $('section.menu-gap').css('margin-top', ($('.navbar.navbar-fixed-top').innerHeight() + $('section.main-navigate').innerHeight()));
}
$(".fancy-dropdown-contain .dropdown-menu li a").click(function() {
    $('.dropdown-menu li a').removeClass('selected');
    $(this).addClass('selected');
    $(this).parents(".fancy-dropdown-contain").find('.dropdown-toggle').html($(this).text() + ' <span class="caret"></span>');
});
$(window).resize(function() {
    responsive_triggers();
});
$(document).on('ready', function() {
    responsive_triggers();
    $('#full-menu .container-fluid').fadeOut();
    $('#full-menu .menu-container').fadeOut();
    $('#full-menu footer').fadeOut();
});