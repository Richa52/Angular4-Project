var slider_length = Math.round($('.dine-filter-list .swiper-slide').length);
var tick_values = [];

function responsive_triggers_brands() {
    var slider_btn_width = $('section.events-slider-container .slider.slider-horizontal .slider-track').width() / slider_length;
    $('section.events-slider-container .slider.slider-horizontal .slider-handle').css({
        'width': slider_btn_width,
        'margin-left': -(slider_btn_width / 2)
    });
    if ($('body').hasClass('relative')) {
        if ($('footer').hasClass('rel-footer')) {
            if (window.innerHeight > document.body.offsetHeight) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        } else {
            if (window.innerHeight > (document.body.offsetHeight) + $('footer').height()) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        }
    }
}

function pagination_events() {
    if ($('.dine-filter-list .next-slide-arrows.swiper-button-disabled').length > 0) {
        if ($('.dine-filter-list .prev-slide-arrows.swiper-button-disabled').length > 0) {
            if ($(window).width() > mobile_breakpoint) {
                $('section.events-slider-container .slider.slider-horizontal').hide();
                $('.dine-filter-list .next-slide-arrows').hide();
                $('.dine-filter-list .prev-slide-arrows').hide();
            } else {
                $('.dine-filter-list .next-slide-arrows').hide();
                $('.dine-filter-list .prev-slide-arrows').hide();
            }
        }
    } else {
        if ($(window).width() > mobile_breakpoint) {
            $('section.events-slider-container .slider.slider-horizontal').show();
            $('.dine-filter-list .next-slide-arrows').hide();
            $('.dine-filter-list .prev-slide-arrows').hide();
        } else {
            $('.dine-filter-list .next-slide-arrows').show();
            $('.dine-filter-list .prev-slide-arrows').show();
        }
    }
}

function brands_swiper_init() {
    var brands_swiper = new Swiper('.dine-filter-list .swiper-container', {
        slidesPerView: 3,
        paginationClickable: true,
        spaceBetween: 30,
        loop: true,
        keyboardControl: true,
        nextButton: '.dine-filter-list .next-slide-arrows',
        prevButton: '.dine-filter-list .prev-slide-arrows',
        breakpoints: {
            520: {
                slidesPerView: 1,
                spaceBetween: 30,
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 30,
            },
            1100: {
                slidesPerView: 3,
                spaceBetween: 30
            },
            1500: {
                slidesPerView: 4,
                spaceBetween: 30
            },
            1700: {
                slidesPerView: 5,
                spaceBetween: 30
            },
            3000: {
                slidesPerView: 6,
                spaceBetween: 30
            },
        },
        onSlideChangeEnd: function(swiper) {
            if ($(window).width() > mobile_breakpoint) {
                $(".index-for-events-slider").bootstrapSlider('setValue', swiper.realIndex);
            }
        }
    });
    pagination_events();
}

if ($(".dine-content").length > 0) {
    var slider_height = $('section.dine-content .event-image-slider').height();
    tl = new TimelineLite({});
    tl.to('.event-image-slider', 1, {
        x: '0%'
    })
    tl.fromTo($('.dine-content>div:nth-child(2)'), 1, {
        opacity: '0',
        y: '20%'
    }, {
        opacity: '1',
        y: '0%'
    }, '+=0.1')
    tl.fromTo($('.dine-content>div:nth-child(3)'), 1, {
        opacity: '0',
        y: '20%'
    }, {
        opacity: '1',
        y: '0%'
    }, '-=0.5')
    tl.fromTo($('.dine-content>div:nth-child(4)'), 1, {
        opacity: '0',
        y: '20%'
    }, {
        opacity: '1',
        y: '0%'
    }, '-=0.5');

    var controller = new ScrollMagic({
        loglevel: 3
    });

    // 2. Curtain Timeline
    var relatedEvents = new TimelineMax( /*{paused: true}*/ );
    relatedEvents //.set('section.related-dining', {opacity: 0})
        .to('section.related-dining', 2, {
        opacity: 1,
        ease: Power4.easeOut
    });

    // 2. Curtain Scene
    var scene = new ScrollScene({
            triggerElement: "section.related-dining" /*, triggerHook: 'onEnter', offset: 203*/
        })
        .addTo(controller)
        .setTween(relatedEvents /*.play()*/ );
}

$(window).resize(function() {
    responsive_triggers_brands();
    pagination_events();
});
$(document).on('ready', function() {
    responsive_triggers_brands();
    $("#search").on('keyup focus', function() {
        if ($('#search').is(":invalid")) {
            $(this).parent().addClass('invalid');
        } else {
            $(this).parent().removeClass('invalid');
        }
    });
    $('.dine-filter-list .swiper-no-results-slide').hide();
    $(".index-for-events-slider").bootstrapSlider({
        ticks: tick_values,
        step: 0.1,
        value: 0,
        ticks_tooltip: false,
    });
    brands_swiper_init();
    $("section.dine-filter .slider-nav>ul>li>a").on('click', function() {
        $('section.dine-filter .slider-nav>ul>li>a').removeClass('active');
        $(this).addClass('active');
    });
    for (var i = 0; i < slider_length; i++) {
        tick_values.push(i);
    }
    $("#datepicker").datepicker({
        minDate: 0,
        dateFormat: "dd/mm/yy",
    });
    $('.reserve_at').click(function(e) {
        e.preventDefault();
        var data = $(this).text();
        $('.time_dropdown .dropdown-toggle').val(data);
    })
    $('#booking_details').validate({
        errorPlacement: function(error, element) {
            return true;
        },
        rules: {
            name: "required",
            phone: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 12,
            },
            date: "required",
            time: "required",
            people: {
                required: true,
                digits: true,
                maxlength: 2,
            },
            email: {
                required: true,
                email: true,
                regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i
            },
            requests: "required",
        },
        submitHandler: function(form) {

        }
    });

    var related_events_swiper = new Swiper('.related-dining .swiper-container', {
        loop: true,
        slidesPerView: 1,
        pagination: '.related-dining .swiper-pagination',
        nextButton: '.related-dining .next-slide-arrows',
        prevButton: '.related-dining .prev-slide-arrows',
        paginationClickable: true,
        breakpoints: {
            560: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            1700: {
                slidesPerView: 4,
                spaceBetween: 70
            },
            3000: {
                slidesPerView: 6,
                spaceBetween: 70
            },
        },
    });
    $(".index-for-events-slider").bootstrapSlider().on('slideStop', function(ev) {
        var current_value = Math.round($('.index-for-events-slider').data('bootstrapSlider').getValue());
        $(".index-for-events-slider").bootstrapSlider('setValue', current_value);
        var brands_swiper = document.querySelector('.dine-filter-list .swiper-container').swiper;
        brands_swiper.slideTo(current_value);
    });
});