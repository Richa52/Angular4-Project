(function($) {
    'use strict';
    // Sort us out with the options parameters
    var getAnimOpts = function(a, b, c) {
            if (!a) {
                return {
                    duration: 'normal'
                };
            }
            if (!!c) {
                return {
                    duration: a,
                    easing: b,
                    complete: c
                };
            }
            if (!!b) {
                return {
                    duration: a,
                    complete: b
                };
            }
            if (typeof a === 'object') {
                return a;
            }
            return {
                duration: a
            };
        },
        getUnqueuedOpts = function(opts) {
            return {
                queue: false,
                duration: opts.duration,
                easing: opts.easing
            };
        };
    // Declare our new effects
    $.fn.showDown = function(a, b, c) {
        var slideOpts = getAnimOpts(a, b, c),
            fadeOpts = getUnqueuedOpts(slideOpts);
        $(this).hide().css('opacity', 0).slideDown(slideOpts).animate({
            opacity: 1
        }, fadeOpts);
    };
    $.fn.hideUp = function(a, b, c) {
        var slideOpts = getAnimOpts(a, b, c),
            fadeOpts = getUnqueuedOpts(slideOpts);
        $(this).show().css('opacity', 1).slideUp(slideOpts).animate({
            opacity: 0
        }, fadeOpts);
    };
}(jQuery));
var slider_length = $('.events .swiper-slide').length;
var half_slider_length = parseInt(slider_length / 2);
var contain_slider_length = $('.events-contain .swiper-slide').length;
var tick_values = [];
if ($('input[type="email"]').length > 0) {
    $.validator.addMethod(
        "regex",
        function(value, element, regexp) {
            if (regexp.constructor != RegExp) regexp = new RegExp(regexp);
            else if (regexp.global) regexp.lastIndex = 0;
            return this.optional(element) || regexp.test(value);
        }
    );
}
$(document).on('ready', function() {
    for (var i = 0; i < slider_length; i++) {
        tick_values.push(i);
    }
    $(".index-for-events-slider").bootstrapSlider({
        ticks: tick_values,
        step: 0.1,
        value: 0,
        ticks_tooltip: false,
    });
    $(".index-for-events-slider").bootstrapSlider('setValue', 0);
    var individual_swiper = new Swiper('.event-image-slider .swiper-container', {
        loop: true,
        slidesPerView: 1,
        pagination: '.event-image-slider .swiper-pagination',
        paginationClickable: true,
    });
    var related_events_swiper = new Swiper('.related-events .swiper-container', {
        loop: true,
        slidesPerView: 1,
        keyboardControl: true,
        pagination: '.related-events .swiper-pagination',
        nextButton: '.related-events .next-slide-arrows',
        prevButton: '.related-events .prev-slide-arrows',
        paginationClickable: true,
        breakpoints: {
            560: {
                slidesPerView: 1,
                spaceBetween: 20
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            1700: {
                slidesPerView: 4,
                spaceBetween: 70
            },
            3000: {
                slidesPerView: 6,
                spaceBetween: 70
            },
        },
    });
    var swiper_img = new Swiper('.events .swiper-container', {
        paginationClickable: true,
        loop: true,
        slideToClickedSlide: true,
        keyboardControl: true,
        onSlideChangeEnd: function(swiper) {
            TweenMax.set('.events .swiper-slide', {
                y: '0%'
            });
            TweenMax.fromTo('.events .swiper-slide-active', 0, {
                y: '0%'
            }, {
                y: '-10%'
            });
            $('.events .swiper-slide>img').css('opacity', '0.2');
            $('.events .swiper-slide-active>img').css('opacity', '1');
            TweenMax.set('.events .swiper-slide>img', {
                opacity: '0.2'
            });
            TweenMax.fromTo('.events .swiper-slide-active>img', 0, {
                opacity: '0.2'
            }, {
                opacity: '1'
            });
            $(".index-for-events-slider").bootstrapSlider('setValue', swiper.realIndex);
            if ($(window).width() > mobile_breakpoint) {} else {}
            TweenMax.set('.events-contain .swiper-slide', {
                opacity: '0'
            });
            TweenMax.set('.events-contain .swiper-slide', {
                display: 'none'
            });
            if (swiper.realIndex == slider_length) {
                TweenMax.fromTo('.events-contain .swiper-slide:nth-child(' + (1) + ')', 0, {
                    display: 'none'
                }, {
                    display: 'table'
                });
                TweenMax.fromTo('.events-contain .swiper-slide:nth-child(' + (1) + ')', 1, {
                    opacity: '0'
                }, {
                    opacity: '1'
                });
            } else {
                TweenMax.fromTo('.events-contain .swiper-slide:nth-child(' + (swiper.realIndex + 1) + ')', 0, {
                    display: 'none'
                }, {
                    display: 'table'
                });
                TweenMax.fromTo('.events-contain .swiper-slide:nth-child(' + (swiper.realIndex + 1) + ')', 1, {
                    opacity: '0'
                }, {
                    opacity: '1'
                });
            }

        },
        breakpoints: {
            768: {
                slidesPerView: 1.2,
                spaceBetween: 20
            },
            1700: {
                slidesPerView: 2.2,
                spaceBetween: 20
            },
            3000: {
                slidesPerView: 3.2,
                spaceBetween: 20
            },
        },
    });
    if ($(".index-for-events-slider").length > 0) {
        $(".index-for-events-slider").bootstrapSlider().on('slideStop', function(ev) {
            var current_value = Math.round($('.index-for-events-slider').data('bootstrapSlider').getValue());
            $(".index-for-events-slider").bootstrapSlider('setValue', current_value);
            swiper_img.slideTo(current_value);
        });
    }
    $('.events-contain .know-more-btn').on('click', function(e) {
        e.preventDefault();
        var image = $('.swiper-slide-active>img');
        var curLeft = image.offset().left;
        var curTop = image.offset().top - $(window).scrollTop();
        var img_width = $('.swiper-slide-active>img').width();
        var goto_img = $('.swiper-slide-active>img')[0].outerHTML;
        goto_img = goto_img.replace("img-responsive", "img-responsive zoomed-img");
        $('body').append(goto_img);
        TweenMax.set('.swiper-slide-active>img', {
            opacity: '0'
        });
        TweenMax.set('.zoomed-img', {
            left: curLeft,
            top: curTop,
            width: img_width
        });
        tl = new TimelineLite({});
        tl.to('.zoomed-img', 4, {
            scale: 4,
            transformOrign: '0% 0%'
        })
        tl.to(['body', '.zoomed-img'], 1, {
            opacity: '0',
            transformOrign: '0% 0%'
        }, '-=4')
        setTimeout(function() {
            window.location = e.target.href;
        }, 1000);
    });
    if ($(".event-content").length > 0) {
        var slider_height = $('section.event-content .event-image-slider').height();
        tl = new TimelineLite({});
        tl.to('.event-image-slider', 1, {
            x: '0%'
        })
        tl.fromTo($('.event-content>div:nth-child(2)'), 1, {
            opacity: '0',
            y: '20%'
        }, {
            opacity: '1',
            y: '0%'
        }, '+=0.1')
        tl.fromTo($('.event-content>div:nth-child(3)'), 1, {
            opacity: '0',
            y: '20%'
        }, {
            opacity: '1',
            y: '0%'
        }, '-=0.5')
        tl.fromTo($('.event-content>div:nth-child(4)'), 1, {
            opacity: '0',
            y: '20%'
        }, {
            opacity: '1',
            y: '0%'
        }, '-=0.5')
        tl.fromTo($('.event-content>div:nth-child(5)'), 1, {
            opacity: '0',
            y: '20%'
        }, {
            opacity: '1',
            y: '0%'
        }, '-=0.5');

        var controller = new ScrollMagic({
            loglevel: 3
        });

        // 2. Curtain Timeline
        var relatedEvents = new TimelineMax( /*{paused: true}*/ );
        relatedEvents
            .to('section.related-events', 2, {
                opacity: 1,
                ease: Power4.easeOut
            });

        // 2. Curtain Scene
        var scene = new ScrollScene({
                triggerElement: "section.related-events" /*, triggerHook: 'onEnter', offset: 203*/
            })
            .addTo(controller)
            .setTween(relatedEvents /*.play()*/ );
    }
});
$(window).load(function() {
    setTimeout(function() {
        var slider_height = $('.events .swiper-container').height();
        $('.events-contain .swiper-wrapper').css('line-height', slider_height + 'px');
        $('.events-contain .swiper-wrapper').css('height', slider_height + 'px');
    }, 1000);
});

$(function() {
    $("#datepicker").datepicker({
        minDate: 0,
        dateFormat: "dd/mm/yy",
    });

    $('#booking_details').validate({
        errorPlacement: function(error, element) {
            return true;
        },
        rules: {
            name: "required",
            phone: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 12,
            },
            email: {
                required: true,
                email: true,
                regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i
            },
        },
        submitHandler: function(form) {

        }
    });
});
if ($('#search').length > 0) {
    if ($('#search').is(":invalid")) {
        $(this).parent().addClass('invalid');
    } else {
        $(this).parent().removeClass('invalid');
    }
}

function responsive_triggers_events() {
    var slider_btn_width = $('section.events-slider-container .slider.slider-horizontal .slider-track').width() / slider_length;
    $('section.events-slider-container .slider.slider-horizontal .slider-handle').css({
        'width': slider_btn_width,
        'margin-left': -(slider_btn_width / 2)
    });
}

$(window).resize(function() {
    responsive_triggers_events();
});
$(document).on('ready', function() {
    responsive_triggers_events();
    $("#search").on('keyup focus', function() {
        if ($('#search').is(":invalid")) {
            $(this).parent().addClass('invalid');
        } else {
            $(this).parent().removeClass('invalid');
        }
    });
});