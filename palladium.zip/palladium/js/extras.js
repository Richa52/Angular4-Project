$(document).on('ready', function() {

});
$(window).load(function() {});

function responsive_triggers_events() {
    if ($('body').hasClass('relative')) {
        if ($('footer').hasClass('rel-footer')) {
            if (window.innerHeight > document.body.offsetHeight) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        } else {
            if (window.innerHeight > (document.body.offsetHeight) + $('footer').height()) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        }
    }
}
$('.faq-head').click(function() {
    $('.panel-collapse.in').collapse('hide');
    $(this).next().collapse('show');
});
if (jQuery().validate) {
    $('#gift_card_form').validate({
        errorPlacement: function(error, element) {
            return true;
        },
        rules: {
            name: "required",
            address: "required",
            email: {
                required: true,
                email: true,
            },
            number: {
                required: true,
                digits: true,
                maxlength: 10,
                minlength: 10
            }
        },
        highlight: function(element, errorClass) {
            $(element).closest('.form_fields').addClass('has-error');
        },
        unhighlight: function(element, errorClass) {
            $(element).closest('.form_fields').removeClass('has-error');
        },
        submitHandler: function(form) {
            //$('.submitRegister').prop('disabled', true);

        }
    });
}
$(window).resize(function() {
    responsive_triggers_events();
});
$(document).on('ready', function() {
    responsive_triggers_events();
    //if(jQuery().Swiper) {  
    var swiper = new Swiper('.gifts-advantages-slider .swiper-container', {
        pagination: '.gifts-advantages-slider .swiper-pagination',
        slidesPerView: 1,
        paginationClickable: true,
        loop: false,
        spaceBetween: 15,
        breakpoints: {
            // when window width is <= 520px
            520: {
                slidesPerView: 1.2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 3.2,
                spaceBetween: 20,
            },
            1100: {
                slidesPerView: 4.2,
                spaceBetween: 30
            },
            1500: {
                slidesPerView: 4,
                spaceBetween: 50
            },
            1700: {
                slidesPerView: 4,
                spaceBetween: 70
            },
            3000: {
                slidesPerView: 4,
                spaceBetween: 20
            },
        },
    });

    var swiper_awards = new Swiper('.year-awards .swiper-container', {
        pagination: '.year-awards .swiper-pagination',
        slidesPerView: 1,
        paginationClickable: true,
        loop: false,
        spaceBetween: 15,
        breakpoints: {
            520: {
                slidesPerView: 1,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            1100: {
                slidesPerView: 3,
                spaceBetween: 20
            },
            1500: {
                slidesPerView: 3,
                spaceBetween: 40
            },
            1700: {
                slidesPerView: 4,
                spaceBetween: 60
            },
            3000: {
                slidesPerView: 5,
                spaceBetween: 60
            },
        },
    });
    var swiper_year = new Swiper('.year-slider .swiper-container', {
        slidesPerView: 5,
        slideToClickedSlide: true,
        loop: false,
        spaceBetween: 15,
        breakpoints: {
            520: {
                slidesPerView: 1.8,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 2.2,
                spaceBetween: 20,
            },
            1100: {
                slidesPerView: 3.4,
                spaceBetween: 20
            },
            1500: {
                slidesPerView: 5,
                spaceBetween: 40
            },
        },
        onSlideChangeEnd: function(swiper) {
            var swiper_timeline = $('.timeline-slider-awards')[0].swiper;
            swiper_timeline.slideTo(swiper.realIndex);
        },
    });
    var swiper_timeline = new Swiper('.timeline-slider-awards', {
        slidesPerView: 1,
        loop: false,
        spaceBetween: 15,
        simulateTouch: false,
        centeredSlides: true,
    });
    swiper_timeline.disableTouchControl();

    $('.year-slider .swiper-container .swiper-slide').on('click', function(swiper, event) {
        var swiper_year = $('.year-slider .swiper-container')[0].swiper;
        $('.year-slider .swiper-wrapper .swiper-slide').removeClass('swiper-slide-prev swiper-slide-active swiper-slide-next');
        $(this).addClass('swiper-slide-active');
        $(this).prev().addClass('swiper-slide-prev');
        $(this).next().addClass('swiper-slide-next');
        var swiper_timeline = $('.timeline-slider-awards')[0].swiper;
        swiper_timeline.slideTo(swiper_year.clickedIndex);
    });
    //}
});