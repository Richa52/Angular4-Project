(function($) {
    'use strict';
    // Sort us out with the options parameters
    var getAnimOpts = function(a, b, c) {
            if (!a) {
                return {
                    duration: 'normal'
                };
            }
            if (!!c) {
                return {
                    duration: a,
                    easing: b,
                    complete: c
                };
            }
            if (!!b) {
                return {
                    duration: a,
                    complete: b
                };
            }
            if (typeof a === 'object') {
                return a;
            }
            return {
                duration: a
            };
        },
        getUnqueuedOpts = function(opts) {
            return {
                queue: false,
                duration: opts.duration,
                easing: opts.easing
            };
        };
    // Declare our new effects
    $.fn.showDown = function(a, b, c) {
        var slideOpts = getAnimOpts(a, b, c),
            fadeOpts = getUnqueuedOpts(slideOpts);
        $(this).hide().css('opacity', 0).slideDown(slideOpts).animate({
            opacity: 1
        }, fadeOpts);
    };
    $.fn.hideUp = function(a, b, c) {
        var slideOpts = getAnimOpts(a, b, c),
            fadeOpts = getUnqueuedOpts(slideOpts);
        $(this).show().css('opacity', 1).slideUp(slideOpts).animate({
            opacity: 0
        }, fadeOpts);
    };
}(jQuery));
$(document).on('ready', function() {
    $('section.main-navigate').css('top', ($('.navbar.navbar-fixed-top').innerHeight()));
    $('section.menu-gap').css('margin-top', ($('.navbar.navbar-fixed-top').innerHeight() + $('section.main-navigate').innerHeight()));

    setTimeout(function() {
        mySlider();
    }, 500);
    $('.pagination>div').on('click', function() {
        gotoSlide($(this));
    });
    autoSlide();
});
var strips = 4;
var container = '#slideshowHolder';
var no_of_slider = $(container + '>div').length;
var pagination = '.pagination';
var slider_wrapper = '.slider-wrapper';
var main_content = '.main-content';
var main_slider = '.main-slider';
var slide_time = 5000;
var slide_animation_time = 1000;
if ($(window).width() > mobile_breakpoint) {
    var slide_shift = '4%';
    var slide_shift = '30px';
} else {
    var slide_shift = '4%';
    var slide_shift = '15px';
}


$(window).resize(function() {
    $('section.main-navigate').css('top', ($('.navbar.navbar-fixed-top').innerHeight()));
    $('section.menu-gap').css('margin-top', ($('.navbar.navbar-fixed-top').innerHeight() + $('section.main-navigate').innerHeight()));
    setTimeout(function() {
        mySlider();
    }, 500);
});


function mySlider() {
    var now = $(container).attr('active-slider');
    updateClasses(now);
    if (!$(container).hasClass('slider-initialized')) {
        for (var i = 0; i < no_of_slider; i++) {
            // $(pagination).append('<div ref-for="' + (i + 1) + '" onclick="gotoSlide(this);"></div>');
            $(pagination).append('<div ref-for="' + (i + 1) + '" ></div>');
        }
    }
    $(container + ' .div-slide').each(function() {
        var contains = $(this).html();
        var img_width = $(this).find(':nth-child(1)').width();
        var width = $(this).width();
        var height = $(this).find(':nth-child(1)').height();
        var strip_width = width / strips;
        var now = $(container);
        $('.timer').css('left', slide_shift);
        if (!$(container).hasClass('slider-initialized')) {
            for (var i = 0; i < strips; i++) {
                $(this).append("<div>" + contains + "</div>");
            }
        }
        var z_index = no_of_slider;
        for (var i = 0; i < strips; i++) {
            $(this).parent().css('position', 'relative');
            $(this).parent().css('overflow', 'hidden');
            $(this).parent().css('height', height + 'px');
            $(this).css('height', height + 'px');
            $(this).find(':nth-child(' + (i + 2) + ')').css('width', strip_width + 'px');
            $(this).find(':nth-child(' + (i + 2) + ')').css('height', height + 'px');
            $(this).find(':nth-child(' + (i + 2) + ')').css('overflow', 'hidden');
            $(this).find(':nth-child(' + (i + 2) + ')').css('position', 'absolute');
            $(this).find(':nth-child(' + (i + 2) + ')').css('top', '0');
            $(this).find(':nth-child(' + (i + 2) + ')').css('left', (strip_width * i) + 'px');
            $(this).find(':nth-child(' + (i + 2) + ')').find('img').css('position', 'absolute');
            $(this).find(':nth-child(' + (i + 2) + ')').find('img').css('width', img_width);
            $(this).find(':nth-child(' + (i + 2) + ')').find('img').css('transform', 'translateX(' + (-strip_width * i) + 'px)');
            z_index--;
        }
    });
    var content_html = $(main_content);
    var pagination_html = $(pagination);
    if ($(window).width() > mobile_breakpoint) {
        $(slider_wrapper).prepend(content_html);
        $(slider_wrapper).after(pagination_html);
    } else {
        $(slider_wrapper).append(content_html);
        $(main_slider).append(pagination_html);
    }
    var now = $(container).attr('active-slider');
    $(container).addClass('slider-initialized');
    updateSlide(now);
}

function updateClasses(now) {
    var now = now;
    $('.div-slide').removeClass('prev-Slide');
    $('.div-slide').removeClass('next-Slide');
    $('.div-slide').removeClass('active');
    $('.pagination>div').removeClass('active');
    $('.div-slide-content').removeClass('active');
    $('.div-slide:nth-child(' + (now) + ')').addClass('active');
    $('.pagination>div:nth-child(' + (now) + ')').addClass('active');
    $('.div-slide-content:nth-child(' + (now) + ')').addClass('active');
    if ($(window).width() > mobile_breakpoint) {
        TweenMax.set('.div-slide-content', {
            x: slide_shift,
            y: '-50%'
        });
    } else {
        TweenMax.set('.div-slide-content', {
            x: '0',
            y: '0'
        });
    }
    if (now == 1) {
        $('.div-slide:nth-child(' + (no_of_slider) + ')').addClass('prev-Slide');
    } else {
        $('.div-slide:nth-child(' + (now - 1) + ')').addClass('prev-Slide');
    }
    if (now == no_of_slider) {
        $('.div-slide:nth-child(' + (1) + ')').addClass('next-Slide');
    } else if (now == 1) {
        $('.div-slide:nth-child(' + (2) + ')').addClass('next-Slide');
    } else {
        $('.div-slide:nth-child(' + (now + 1) + ')').addClass('next-Slide');
    }
}

function nextSlide() {
    var now = $(container).attr('active-slider');
    now++;
    if (now > no_of_slider) {
        now = 1;
    }
    updateSlide(now);
}

function prevSlide() {
    var now = $(container).attr('active-slider');
    now--;
    if (now == 0) {
        now = no_of_slider;
    }
    updateSlide(now);
}

function gotoSlide(slide) {
    var now = slide.getAttribute("ref-for");
    updateSlide(now);
}

function autoSlide() {
    setInterval(function() {
        nextSlide();
    }, (slide_time + 2000));
}

function updateSlide(now) {
    $(".timer").stop();
    timerReset();
    updateClasses(now);
    $('.timer').css('height', "0%");
    $(container).attr('active-slider', now);
    $('.div-slide').each(function() {
        for (var i = 0; i < strips; i++) {
            $(this).find(':nth-child(' + (i + 2) + ')').hide();
        }
    });
    $('.div-slide.next-Slide').each(function() {
        for (var i = 0; i < strips; i++) {
            $(this).find(':nth-child(' + (i + 2) + ')').show();
        }
    });
    $('.div-slide.active').each(function() {
        for (var i = 0; i < strips; i++) {
            $(this).find(':nth-child(' + (i + 2) + ')').show("slide", {
                direction: "left"
            }, slide_animation_time);
        }
    });
    if ($(window).width() > mobile_breakpoint) {
        $('.div-slide-content.active').showDown('slow');
    }
    TweenMax.set('.div-slide', {
        left: '0'
    });
    setTimeout(function() {
        TweenMax.fromTo('.div-slide.active', 1, {
            left: 0
        }, {
            left: slide_shift,
            onComplete: timerGo
        });
    }, (slide_animation_time + 500));

    function timerGo() {
        TweenMax.fromTo('.timer', (slide_time / 1000), {
            height: 0
        }, {
            height: '100%' /*,ease:Expo.easeOut*/ ,
            onComplete: timerReset
        });
    }

    function timerReset() {
        TweenMax.to('.timer', 0, {
            height: 0
        });

        if ($(window).width() > mobile_breakpoint) {
            $('.div-slide-content.active').hideUp('fast', function() {});
        }
    }
}