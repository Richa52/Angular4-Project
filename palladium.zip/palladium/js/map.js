var locations = [
    ['Mumbai Palladium, <br>462, Senapati Bapat Marg,<br>Lower Parel (West), <br>Mumbai - 400 013. ', 18.9940439, 72.8229014],
];

function initMap() {
    var uluru = {
        lat: 18.9940439,
        lng: 72.8229014
    };
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 17,
        center: uluru
    });

    var contentString = '<strong>Mumbai Palladium</strong>, <br>462, Senapati Bapat Marg,<br>Lower Parel (West), <br>Mumbai - 400 013.';

    var infowindow = new google.maps.InfoWindow({
        content: contentString
    });

    var marker = new google.maps.Marker({
        position: uluru,
        map: map,
        title: 'Mumbai Palladium'
    });
    infowindow.open(map, marker);
}

$.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        if (regexp.constructor != RegExp) regexp = new RegExp(regexp);
        else if (regexp.global) regexp.lastIndex = 0;
        return this.optional(element) || regexp.test(value);
    }
);
//Add Modernizr test
Modernizr.addTest('isios', function() {
    return navigator.userAgent.match(/(iPad|iPhone|iPod)/g);
});

$(function() {
    $('#contact_details').validate({
        errorPlacement: function(error, element) {
            return true;
        },
        rules: {
            name: "required",
            phone: {
                required: true,
                digits: true,
                minlength: 10,
                maxlength: 12,
            },
            email: {
                required: true,
                email: true,
                regex: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i
            },
            message: "required",
        },
        submitHandler: function(form) {

        }
    });
});
$('.getdirection a').on('click', function(e) {
    var goto_url = e.target.attributes.directions.value;
    if ($(window).width() > mobile_breakpoint) {
        e.preventDefault();
        window.open(goto_url, '_blank');
    } else {
        // If it's an iPhone..
        if (_iOSDevice = !!navigator.platform.match(/iPhone|iPod|iPad/)) {
            e.preventDefault();
            window.open("https://maps.apple.com/?daddr=Palladium+Mumbai&dirflg=r");
        } else {
            // window.location= "http://maps.google.com/?daddr=Palladium+Mumbai";
        }
    }
});