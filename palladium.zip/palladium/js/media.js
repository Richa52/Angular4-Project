$(window).load(function() {});

$(function() {
    $("#date").datepicker({
        numberOfMonths: 1,
        onSelect: function(selectedDate) {
            if (!$(this).data().datepicker.first) {
                $(this).data().datepicker.inline = true
                $(this).data().datepicker.first = selectedDate;
            } else {
                if (selectedDate > $(this).data().datepicker.first) {
                    $(this).val($(this).data().datepicker.first + " - " + selectedDate);
                } else {
                    $(this).val(selectedDate + " - " + $(this).data().datepicker.first);
                }
                $(this).data().datepicker.inline = false;
            }
        },
        onClose: function() {
            delete $(this).data().datepicker.first;
            $(this).data().datepicker.inline = false;
        }
    })
    $('#query-form').validate({
        errorPlacement: function(error, element) {
            return true;
        },
        rules: {
            name: "required",
            email: {
                required: true,
                email: true
            },
            number: {
                required: true,
                digits: true,
                maxlength: 10,
                minlength: 10
            },
            message: "required"
        },
    });
});

function responsive_triggers_media() {
    if ($('body').hasClass('relative')) {
        if ($('footer').hasClass('rel-footer')) {
            if (window.innerHeight > document.body.offsetHeight) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        } else {
            if (window.innerHeight > (document.body.offsetHeight) + $('footer').height()) {
                $('footer').addClass('fixed-footer');
                $('footer').removeClass('rel-footer');
            } else {
                $('footer').addClass('rel-footer');
                $('footer').removeClass('fixed-footer');
            }
        }
    }
}

$(window).resize(function() {
    responsive_triggers_media();
});
$(document).on('ready', function() {
    responsive_triggers_media();
    var media_menu = new Swiper('.media-menu .swiper-container', {
        slidesPerView: 'auto',
        spaceBetween: 35,
        freeMode: true,
    });
    var current_menu = ($('section.media-menu .swiper-slide.active').index());
    if (current_menu != -1) {
        media_menu.slideTo(current_menu, 1, false);
    }
    var press_posts = new Swiper('section.press .swiper-container', {
        slideClass: 'media-post',
        slidesPerView: 1,
        slidesPerColumn: 5,
        spaceBetween: 30,
        pagination: 'section.press .swiper-pagination',
        breakpoints: {
            520: {
                slidesPerView: 1,
                slidesPerColumn: 5,
                spaceBetween: 30,
            },
            768: {
                slidesPerView: 2,
                slidesPerColumn: 5,
                spaceBetween: 30,
            },
            1100: {
                slidesPerView: 2,
                slidesPerColumn: 3,
                spaceBetween: 30
            },
            1500: {
                slidesPerView: 2,
                slidesPerColumn: 3,
                spaceBetween: 44
            },
            1700: {
                slidesPerView: 3,
                slidesPerColumn: 3,
                spaceBetween: 44
            },
            3000: {
                slidesPerView: 3,
                slidesPerColumn: 3,
                spaceBetween: 44
            },
        },
    });
});