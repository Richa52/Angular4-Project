$(document).ready(function(){
    var swiper = new Swiper('.year-awards .swiper-container', {
      pagination: '.year-awards .swiper-pagination',
      slidesPerView: 1,
      paginationClickable: true,
      loop:false,
      spaceBetween: 15,
    });

    $("#history").css("overflow-x", "auto");
    // $('#history').dragScroll({}); 
    $('#history').attachDragger();
    var sheet = document.createElement('style'),
    $rangeInput = $('.range input');
    prefs = ['webkit-slider-runnable-track', 'moz-range-track', 'ms-track'];
    prefsinput = ['webkit-slider-thumb', 'moz-range-thumb', 'ms-thumb'];
    var fullRange=$('.range');
    var fullSlider=$('.range-labels');
    var number_of_items=fullSlider.find('li').length;
    // var perWidth=fullSlider.width()/fullSlider.find('li').length;
    var perWidth=180;
    var scrollWidth=perWidth-30;
    // fullRange.width(perWidth*(number_of_items+1));


    fullSlider.find('li').css('width',perWidth);
      



      document.body.appendChild(sheet);
      var getTrackStyle = function(el) {
        // console.log(el);
        // return;
        var curVal = el.value;

          if(isNaN(curVal)){
            curVal=1;
          }
          val = ((curVal-1) * perWidth)+104;//+(perWidth/2);
          dotval = ((curVal-1) * perWidth)+100;//+(perWidth/2);
          style = '';
          //val=($('.range-labels li.active.selected').offset().left)+(perWidth/2);
          // console.log('val='+val+',\ncurVal='+curVal+',\nperWidth='+perWidth);
        // Set active label
        $('.range-labels li').removeClass('active selected');
        var curLabel = $('.range-labels').find('li:nth-child(' + curVal + ')');
        curLabel.addClass('active selected');
        curLabel.prevAll().addClass('selected');
        // Change background gradient
        for (var i = 0; i < prefs.length; i++) {
          style += '.range {background: linear-gradient(to right, #ec1c24 0px, #ec1c24 ' + val + 'px, #fff ' + val + 'px, #fff 100%)}';
          style += '.range input::-' + prefs[i] + '{background: linear-gradient(to right, #ec1c24 0px, #ec1c24 ' + val + 'px, #ec1c24 ' + val + 'px, #ec1c24 100%)}';
          style += '.range input::-' + prefsinput[i] + '{left :' + dotval + 'px}';
        }
        return style;
      }
      $rangeInput.on('input', function() {
        sheet.textContent = getTrackStyle(this);
      });


      function onloadfunction($rangeInput) {
        //var $rangeInput1=$rangeInput.find('input');
        sheet.textContent = getTrackStyle($rangeInput);
      };


      //getTrackStyle($('#rangeinput'));
      var swiper1 = new Swiper('.timeline-slider-awards',{
        autoHeight:true,
        /*nextButton: '.about-us-home-new .next',
        prevButton: '.about-us-home-new .before',*/
        onSlidePrevEnd: function(swiper) {
          $rangeInput.val(swiper.activeIndex+1).trigger('input');
          $('#history').animate( { scrollLeft: '-='+scrollWidth+'' }, 1000, 'easeOutQuad' );
        },
        onSlideNextStart: function(swiper) {
          $rangeInput.val(swiper.activeIndex+1).trigger('input');
          // console.log(swiper.activeIndex);
          if(swiper.activeIndex==10){
            // alert();
            $('#history').animate( { scrollLeft: '+='+(scrollWidth+50)+'' }, 1000, 'easeOutQuad' );
          }else{            
            if(swiper.activeIndex==12){
              // alert();
              $('#history').animate( { scrollLeft: '+='+(scrollWidth+100)+'' }, 1000, 'easeOutQuad' );
            }else{          
              if(swiper.activeIndex==14){
                // alert();
                $('#history').animate( { scrollLeft: '+='+(scrollWidth+100)+'' }, 1000, 'easeOutQuad' );
              }else{
                $('#history').animate( { scrollLeft: '+='+(scrollWidth)+'' }, 1000, 'easeOutQuad' );
              }
            }
          }
        },
      });

      // Change input value on label click
      $('.range-labels li').on('click', function() {
        var index = $(this).index();
        $rangeInput.val(index + 1).trigger('input');
        swiper1.slideTo(index);
      }); 
      $rangeInput.val('2');
      //alert($rangeInput.val());
      $rangeInput.trigger('change');
      //alert($rangeInput.val());

      onloadfunction($rangeInput);
      /*$(function() {
          if (Modernizr.touch) {
              $("#history").css("overflow-x", "auto");
          }
      });*/
      // $("#history").css("overflow-x", "auto");
  });/*ends document ready*/



$.fn.attachDragger = function(){
    var attachment = false, lastPosition, position, difference;
    $( $(this).selector ).on("mousedown mouseup mousemove",function(e){
        if( e.type == "mousedown" ) attachment = true, lastPosition = [e.clientX, e.clientY];
        if( e.type == "mouseup" ) attachment = false;
        if( e.type == "mousemove" && attachment == true ){
            position = [e.clientX, e.clientY];
            difference = [ (position[0]-lastPosition[0]), (position[1]-lastPosition[1]) ];
            $(this).scrollLeft( $(this).scrollLeft() - difference[0] );
            $(this).scrollTop( $(this).scrollTop() - difference[1] );
            lastPosition = [e.clientX, e.clientY];
        }
    });
    $(window).on("mouseup", function(){
        attachment = false;
    });
}