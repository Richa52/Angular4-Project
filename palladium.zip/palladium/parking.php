<?php include('common.php'); $page='parking'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Parking</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="nonseo relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="parking left-spacer">
        <div class="line-header">Valet Parking</div>      
    </section>
    <section class="parking-container left-spacer right-spacer container-fluid">
        <div class="parking-list">
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/available-on-all.png">Available on all days
                </div>
            </div>
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/valet-drop-off.png">Valet drop off point West Court Lobby
                </div>
            </div>
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/pickup-point.png">Pick up point P1 Parking level
                </div>
            </div>
        </div>
        <div class="parking-description"><span>Weekday charges :</span> Rs. 150 for the first 5 hours and Rs. 100 for every additional hour after 5 hours <br>
        <span>Weekend charges :</span> Rs. 200 for the first 5 hours and Rs. 100 for every additional hour adfter 5 hours</div> 
    </section>
    <section class="parking left-spacer">
        <div class="line-header">Parking</div>    
    </section>
    <section class="parking-container left-spacer right-spacer container-fluid">
        <div class="parking-list">
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/seven-levels.png">Seven levels of Parking
                </div>
            </div>
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/total-capacity.png">Total capacity of 1177 cars
                </div>
            </div>
            <div class="parking-item">
                <div class="contain" style="max-width: 190px;">
                    <img src="<?php echo $base_url ?>img/parking/reserved-for.png">Reservations for handicapped customers &amp; expectant mothers
                </div>
            </div>
            <div class="parking-item">
                <div class="contain">
                    <img src="<?php echo $base_url ?>img/parking/bays-on-each-levels.png">4 bays on each level near the lift lobbies
                </div>
            </div>
        </div>
        <div class="parking-description"><span>Rates : </span> 0-30 minutes – Free <span class="part-line"></span> 30 mins – 60 minutes – Rs. 50 <span class="part-line"></span> 1hour – 2 hours – Rs. 75 <span class="part-line"></span> 2 hours – 4 hours – Rs. 100<br>
        <span>Every additional hour :</span>  Rs. 100 per hour</div> 
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
