<?php include('common.php'); $page='tandc'; ?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Palladium - Terms &amp; Conditions</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?php echo $base_url ?>favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/slick-theme.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/swiper.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/bootstrap-slider.min.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/jquery-ui.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/common.css">
        <link rel="stylesheet" href="<?php echo $base_url ?>css/extras.css">

        <script src="<?php echo $base_url ?>js/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body class="nonseo relative">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]--> 
    <?php include('header.php'); ?>


    <section class="menu-gap"></section>
    <section class="extras-header left-spacer">
        <div class="line-header">Terms &amp; Conditions</div>       
    </section>
    <section class="tandc-container left-spacer right-spacer container-fluid">   
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas consequat lorem quis justo vulputate aliquam. Proin non mi imperdiet lorem euismod auctor at ut erat. Proin in neque nec neque commodo ornare. Sed in diam tempor orci pharetra imperdiet. Praesent et arcu eu ante egestas lacinia sed eu nisl. Etiam pulvinar ullamcorper tempor. Nulla in magna at sapien vestibulum dictum sed in sem. <br><br>

        Nulla ac gravida dui, quis varius erat. Phasellus interdum a ipsum sed luctus. Integer tortor orci, convallis ac nibh non, congue rhoncus risus. Aliquam porttitor lectus eu fermentum scelerisque. Proin quis nulla at ligula pretium vehicula non id velit. Pellentesque fringilla finibus ornare. Pellentesque maximus vestibulum enim. Cras ipsum magna, pellentesque vel quam at, tincidunt lobortis libero.<br><br>

        Suspendisse ac aliquam neque. Proin convallis rhoncus quam, nec fermentum tellus rutrum ut. Sed consequat non nulla sit amet pellentesque. Donec ullamcorper suscipit ligula, id luctus metus porta efficitur. Fusce mollis elit neque, vel porttitor lorem sollicitudin a. Vestibulum nec tortor non nisl sollicitudin tristique sit amet quis velit. Donec elit nibh, ullamcorper quis aliquet sed, luctus eu nisl. Aliquam at augue eget augue rhoncus egestas vel a lectus. Vestibulum ultrices non nisi vel imperdiet. Nulla cursus, metus quis venenatis condimentum, metus dolor vestibulum ex, at scelerisque sapien nulla nec eros. Maecenas eu magna malesuada lectus iaculis pharetra in sit amet libero. Nam auctor malesuada imperdiet. Duis et eros odio.<br><br>

        Nullam ut arcu ornare, interdum nulla in, interdum augue. Ut non tristique nulla. Nulla a augue id enim mattis consectetur. Fusce eu ex lacinia, egestas velit feugiat, luctus arcu. Maecenas id scelerisque ex. Ut et augue erat. Donec urna orci, blandit id rutrum ac, semper nec mauris. Donec interdum rutrum sem sollicitudin tristique. Phasellus nec pretium ante, ac tristique massa. Maecenas varius fringilla euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius cursus eros, ut consectetur orci mattis et. Mauris et mi porttitor, congue lorem eget, aliquam justo. Etiam tincidunt egestas tortor, eget laoreet eros lacinia sit amet. Nullam sed imperdiet massa.<br><br>

        Mauris ut nisl justo. Ut nibh ex, feugiat et gravida ornare, tincidunt ac libero. Suspendisse tristique quam libero, et vehicula nisl vehicula a. Curabitur maximus metus venenatis velit congue finibus. Nulla quis porttitor est. Aenean feugiat elit in est tempor molestie. Sed sollicitudin quis lorem quis efficitur. Pellentesque iaculis a odio id bibendum. Mauris euismod placerat magna a efficitur. Sed pretium eros mi, vel tempor dolor hendrerit ut. Nunc tempus nec turpis et eleifend. Nullam nec varius libero, ut vehicula diam. Vivamus congue pellentesque orci nec vehicula. Suspendisse a lorem at lectus gravida pretium.  
    </section>
    <?php include('footer.php'); ?>
    <?php include('footer-js.php'); ?>
   
        
    </body>
</html>
